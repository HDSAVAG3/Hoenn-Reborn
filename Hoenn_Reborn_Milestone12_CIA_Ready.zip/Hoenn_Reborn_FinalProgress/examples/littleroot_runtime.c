#include "map_runtime.h"

static const uint16_t LittlerootLike_blocks[] = {
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
    1, 2, 2, 2, 1, 1, 1, 3, 3, 2, 2, 1,
    1, 2, 4, 2, 1, 1, 1, 2, 2, 2, 2, 1,
    1, 2, 2, 2, 1, 1, 1, 2, 5, 2, 2, 1,
    1, 1, 1, 1, 1, 1, 1, 2, 2, 2, 2, 1,
    1, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1,
    1, 2, 2, 6, 2, 2, 1, 1, 1, 1, 1, 1,
    1, 2, 2, 2, 2, 2, 1, 1, 1, 1, 1, 1,
    1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1
};
static const uint8_t LittlerootLike_collision[] = {
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 0, 0, 0, 1, 1, 1, 1, 0,
    0, 1, 0, 1, 0, 0, 0, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 0, 0, 0, 1, 0, 1, 1, 0,
    0, 0, 0, 0, 0, 0, 0, 1, 1, 1, 1, 0,
    0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0,
    0, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0, 0,
    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};
static const RuntimeWarp LittlerootLike_warps[] = {
    {5, 5, 2, 0},
};
static const RuntimeConnection LittlerootLike_connections[] = {
    {CONN_EAST, 0, 2},
};
const RuntimeMap LittlerootLike_runtime_map = {
    1, "LittlerootLike",
    {12, 9, LittlerootLike_blocks, LittlerootLike_collision, 6},
    LittlerootLike_warps, 1,
    LittlerootLike_connections, 1
};
