#!/usr/bin/env python3
"""Validate a Hoenn Reborn map-v2 JSON package."""
import json, sys
from pathlib import Path


def main():
    if len(sys.argv) != 2:
        raise SystemExit("usage: map_import_contract.py <map.json>")
    d = json.loads(Path(sys.argv[1]).read_text(encoding="utf-8"))
    w, h = int(d["width"]), int(d["height"])
    blocks = d["blocks"]
    collision = d["collision"]
    if not (0 < w <= 512 and 0 < h <= 512):
        raise SystemExit("invalid dimensions")
    if len(blocks) != w * h:
        raise SystemExit("blocks length does not match width*height")
    if len(collision) != w * h:
        raise SystemExit("collision length does not match width*height")
    if any(int(v) < 0 for v in blocks):
        raise SystemExit("negative block id")
    if any(int(v) not in (0, 1) for v in collision):
        raise SystemExit("collision must contain only 0 or 1")
    if int(d.get("block_count", 0)) <= 0:
        raise SystemExit("block_count must be positive")
    for c in d.get("connections", []):
        if c.get("direction") not in {"up", "down", "left", "right", "north", "south", "west", "east"}:
            raise SystemExit(f"invalid connection direction: {c.get('direction')}")
        if c.get("dest_map") is None:
            raise SystemExit("connection is missing dest_map")
    for i, wdata in enumerate(d.get("warps", [])):
        if int(wdata.get("warp_id", i)) != i:
            raise SystemExit("warp_id values must be zero-based and contiguous")
        if wdata.get("dest_map") is None:
            raise SystemExit("warp is missing dest_map")
    print(f"valid map-v2: {d.get('name','unnamed')} {w}x{h}, {d['block_count']} blocks, {len(d.get('warps', []))} warps, {len(d.get('connections', []))} connections")

if __name__ == "__main__":
    main()
