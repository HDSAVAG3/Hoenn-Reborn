#!/usr/bin/env python3
from pathlib import Path
import hashlib, sys

if len(sys.argv) != 2:
    raise SystemExit("usage: rom_manifest.py <emerald.gba>")

p = Path(sys.argv[1])
data = p.read_bytes()

print("size:", len(data))
print("sha1:", hashlib.sha1(data).hexdigest())
print("md5:", hashlib.md5(data).hexdigest())
print("game code:", data[0xAC:0xB0].decode("ascii", errors="replace"))
print("revision:", data[0xBC])
print()
print("This probe only identifies the input ROM.")
print("It intentionally does not export Nintendo ROM bytes or assets.")
