#!/usr/bin/env python3
"""Find candidate Emerald graphics files for a map without exporting them."""
from pathlib import Path
import json, sys

def main():
    if len(sys.argv)!=3: raise SystemExit('usage: emerald_graphics_probe.py <pokeemerald-root> <MapName>')
    root=Path(sys.argv[1]).resolve(); name=sys.argv[2]
    m=json.loads((root/'data/maps'/name/'map.json').read_text())
    layouts=json.loads((root/'data/layouts/layouts.json').read_text())['layouts']
    layout=next(x for x in layouts if x['id']==m['layout'])
    out={'map':name,'layout_id':m['layout'],'primary_tileset':layout.get('primary_tileset'),'secondary_tileset':layout.get('secondary_tileset'),'candidates':[]}
    for key in ('primary_tileset','secondary_tileset'):
        ts=layout.get(key)
        if not ts: continue
        clean=ts.replace('TILESET_','').lower()
        for base in [root/'data/tilesets', root/'graphics/tilesets']:
            hits=list(base.rglob(f'*{clean}*')) if base.exists() else []
            out['candidates'] += [str(p.relative_to(root)) for p in hits[:50]]
    print(json.dumps(out, indent=2))
    print('\nProbe only. No source assets are copied into Hoenn Reborn.')

if __name__=='__main__': main()
