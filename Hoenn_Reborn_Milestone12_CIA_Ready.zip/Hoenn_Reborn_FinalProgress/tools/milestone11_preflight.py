#!/usr/bin/env python3
"""Milestone 11 host-side preflight: validate project layout and run self-tests."""
from pathlib import Path
import subprocess, sys

ROOT = Path(__file__).resolve().parents[1]
required = [
    "Makefile", "README.md", "assets/icon/icon.png", "assets/banner/banner.png",
    "assets/hoenn_reborn.rsf", "src/main.c", "include/overworld.h",
    "tools/package_cia.sh", "examples/emerald_rom_manifest.json",
]
failed = []
for rel in required:
    p = ROOT / rel
    if not p.is_file() or p.stat().st_size == 0:
        failed.append(f"missing/empty: {rel}")

scripts = [
    "tools/milestone6_selftest.py",
    "tools/milestone7_selftest.py",
    "tools/milestone8_selftest.py",
    "tools/simulate_warps.py",
    "tools/milestone12_selftest.py",
]
for rel in scripts:
    p = ROOT / rel
    r = subprocess.run([sys.executable, str(p)], cwd=ROOT, text=True,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
    print(r.stdout, end="")
    if r.returncode != 0:
        failed.append(f"self-test failed: {rel}")

makefile = (ROOT / "Makefile").read_text(encoding="utf-8")
for needle in ("$(DEVKITARM)/bin/arm-none-eabi-gcc", "3dsxtool", "package_cia.sh"):
    if needle not in makefile:
        failed.append(f"Makefile missing expected build hook: {needle}")

if failed:
    print("\nMilestone 11 preflight: FAIL")
    for item in failed:
        print("-", item)
    raise SystemExit(1)

print("\nMilestone 11 preflight: PASS")
print("- project files present")
print("- milestones 6-8 regression tests pass")
print("- warp smoke test passes")
print("- 3DS toolchain hooks present")
print("- Milestone 12 graphical renderer validated")
