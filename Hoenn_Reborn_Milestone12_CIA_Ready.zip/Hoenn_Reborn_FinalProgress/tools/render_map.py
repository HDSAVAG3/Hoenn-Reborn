#!/usr/bin/env python3
"""Render a normalized Hoenn Reborn map package to PNG.

This is a project-owned adapter format. It supports GBA 4bpp tile graphics and
RGB555 palettes, but it does not extract or redistribute Nintendo assets.
"""
from __future__ import annotations
import json, struct, sys
from pathlib import Path
from PIL import Image

TILE_W = TILE_H = 8
METATILE_TILES = 4
BLOCK_METATILES = 4

def gba4bpp(data: bytes, tile_index: int):
    off = tile_index * 32
    chunk = data[off:off+32]
    if len(chunk) != 32:
        raise ValueError(f"missing 4bpp tile {tile_index}")
    out = []
    for y in range(8):
        row = chunk[y*4:y*4+4]
        for b in row:
            out.append(b & 0xF)
            out.append((b >> 4) & 0xF)
    return out

def rgb555(v: int):
    r = (v & 0x1F) * 255 // 31
    g = ((v >> 5) & 0x1F) * 255 // 31
    b = ((v >> 10) & 0x1F) * 255 // 31
    return (r, g, b)

def load_palette(path: Path):
    d = json.loads(path.read_text())
    colors = d["colors"]
    if len(colors) != 16:
        raise ValueError("palette.json must contain exactly 16 colors")
    if isinstance(colors[0], int):
        return [rgb555(x) for x in colors]
    return [tuple(x) for x in colors]

def draw_tile(dst, x0, y0, tile, palette, flip_x=False, flip_y=False):
    for y in range(8):
        for x in range(8):
            sx = 7-x if flip_x else x
            sy = 7-y if flip_y else y
            idx = tile[sy*8+sx]
            dst.putpixel((x0+x, y0+y), palette[idx])

def render(args):
    root = Path(args[0])
    out = Path(args[1])
    m = json.loads((root / "map.json").read_text())
    meta = json.loads((root / "metatiles.json").read_text())["metatiles"]
    blocks = json.loads((root / "blocks.json").read_text())["blocks"]
    tiles = (root / "tiles_4bpp.bin").read_bytes()
    palette = load_palette(root / "palette.json")
    width, height = int(m["width"]), int(m["height"])
    img = Image.new("RGB", (width*32, height*32), palette[0])
    cache = {}
    for by in range(height):
        for bx in range(width):
            bid = int(m["blocks"][by*width+bx])
            if bid >= len(blocks): raise ValueError(f"block {bid} missing")
            for q, mid in enumerate(blocks[bid]):
                mx, my = q % 2, q // 2
                if mid >= len(meta): raise ValueError(f"metatile {mid} missing")
                for t, spec in enumerate(meta[mid]):
                    tile_id = int(spec["tile"])
                    fx = bool(spec.get("flip_x", False)); fy = bool(spec.get("flip_y", False))
                    if tile_id not in cache: cache[tile_id] = gba4bpp(tiles, tile_id)
                    tx, ty = t % 2, t // 2
                    draw_tile(img, bx*32+mx*16+tx*8, by*32+my*16+ty*8,
                              cache[tile_id], palette, fx, fy)
    out.parent.mkdir(parents=True, exist_ok=True)
    img.save(out)
    print(f"rendered {width}x{height} blocks -> {out} ({img.width}x{img.height}px)")

def main():
    if len(sys.argv) != 3:
        raise SystemExit("usage: render_map.py <normalized-gfx-dir> <out.png>")
    render(sys.argv[1:])

if __name__ == "__main__": main()
