#!/usr/bin/env python3
"""Create a project-owned procedural 3-frame directional player sheet for testing."""
from pathlib import Path
import json, sys
try:
    from PIL import Image, ImageDraw
except ImportError:
    raise SystemExit('Pillow is required: python3 -m pip install pillow')

out=Path(sys.argv[1] if len(sys.argv)>1 else 'examples/milestone6/player_sheet.png'); out.parent.mkdir(parents=True,exist_ok=True)
img=Image.new('RGBA',(12*4,16*4),(0,0,0,0)); d=ImageDraw.Draw(img)
for direction,ox in [('down',0),('up',12),('left',24),('right',36)]:
    for frame in range(3):
        x=ox+frame*4; y=0
        # tiny abstract person; deliberately not a Pokémon/Nintendo sprite
        bob=1 if frame==1 else 0
        d.rectangle((x+1,y+1+bob,x+2,y+2+bob),fill=(255,255,255,255))
        d.point((x+1,y+1+bob),fill=(0,0,0,255))
        d.rectangle((x+1,y+3+bob,x+2,y+5+bob),fill=(255,255,255,255))
        if direction in ('left','right'):
            d.point((x+(0 if direction=='left' else 3),y+3+bob),fill=(255,255,255,255))
        d.point((x+1,y+6+bob),fill=(255,255,255,255)); d.point((x+2,y+6+bob),fill=(255,255,255,255))
img.resize((img.width*8,img.height*8),Image.Resampling.NEAREST).save(out)
out.with_suffix('.json').write_text(json.dumps({'format':'hoenn-reborn-player-sprite-v1','frame_size':[4,8],'frames':3,'directions':['down','up','left','right'],'source':'development-procedural'},indent=2)+'\n')
print(out)
