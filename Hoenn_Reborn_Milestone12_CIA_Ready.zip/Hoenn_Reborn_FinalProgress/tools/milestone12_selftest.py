#!/usr/bin/env python3
"""Static/host validation for the Milestone 12 framebuffer renderer."""
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
checks = {
    "scene renderer header": ROOT / "include/scene_renderer.h",
    "scene renderer implementation": ROOT / "src/scene_renderer.c",
    "milestone 12 docs": ROOT / "docs/MILESTONE12.md",
}
for label, path in checks.items():
    assert path.is_file() and path.stat().st_size > 0, f"missing {label}: {path}"

scene = (ROOT / "src/scene_renderer.c").read_text(encoding="utf-8")
main = (ROOT / "src/main.c").read_text(encoding="utf-8")
over = (ROOT / "src/overworld.c").read_text(encoding="utf-8")
dialogue = (ROOT / "src/dialogue.c").read_text(encoding="utf-8")

for needle in (
    "gfxGetFramebuffer(GFX_TOP",
    "GSP_RGB565_OES",
    "scene_renderer_draw_world",
    "scene_renderer_draw_dialogue",
    "draw_actor",
    "draw_tile",
):
    assert needle in scene, f"scene renderer missing: {needle}"

assert "consoleInit(GFX_TOP" not in main, "top gameplay must not use the console"
assert "consoleInit(GFX_BOTTOM" in main, "bottom debug console missing"
assert "scene_renderer_draw_world" in over, "overworld not routed to graphical renderer"
assert "scene_renderer_draw_dialogue" in dialogue, "dialogue not routed to graphical renderer"

print("Milestone 12 self-test: PASS")
print("- top framebuffer renderer present")
print("- RGB565 scene path present")
print("- map/camera/player/NPC rendering hooks present")
print("- dialogue is gameplay-rendered")
print("- bottom console remains debug-only")
