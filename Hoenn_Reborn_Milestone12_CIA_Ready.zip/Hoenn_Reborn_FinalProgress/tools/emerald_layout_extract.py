#!/usr/bin/env python3
"""Extract map-layout block grids from a local pokeemerald source tree.

This tool intentionally emits only structural/generated data needed by Hoenn
Reborn. It does not package Nintendo graphics, audio, scripts, or ROM bytes.

Usage:
  emerald_layout_extract.py <pokeemerald-root> <MapName> <out.json>

The source tree must contain data/maps/<MapName>/map.json and
 data/layouts/layouts.json plus the layout's blockdata_filepath.
"""
from __future__ import annotations
import json, struct, sys
from pathlib import Path


def load_json(p: Path):
    return json.loads(p.read_text(encoding="utf-8"))


def main() -> int:
    if len(sys.argv) != 4:
        print("usage: emerald_layout_extract.py <pokeemerald-root> <MapName> <out.json>")
        return 2

    root = Path(sys.argv[1]).resolve()
    map_name = sys.argv[2]
    out = Path(sys.argv[3])
    map_json = load_json(root / "data" / "maps" / map_name / "map.json")
    layouts = load_json(root / "data" / "layouts" / "layouts.json")["layouts"]
    layout_id = map_json["layout"]
    matches = [x for x in layouts if x.get("id") == layout_id]
    if len(matches) != 1:
        raise SystemExit(f"layout {layout_id!r} not found uniquely")
    layout = matches[0]

    width = int(layout["width"])
    height = int(layout["height"])
    block_path = root / layout["blockdata_filepath"]
    raw = block_path.read_bytes()
    if len(raw) % 2:
        raise SystemExit(f"blockdata has odd byte count: {block_path}")
    blocks = list(struct.unpack("<" + "H" * (len(raw)//2), raw))
    expected = width * height
    if len(blocks) < expected:
        raise SystemExit(f"blockdata too small: need {expected} u16 values, got {len(blocks)}")
    blocks = blocks[:expected]

    result = {
        "format": "hoenn-reborn-map-v2",
        "source": "pokeemerald-layout",
        "name": map_name,
        "layout_id": layout_id,
        "width": width,
        "height": height,
        "block_count": (max(blocks) + 1) if blocks else 0,
        "blocks": blocks,
        "collision": [1] * expected,
        "border_width": int(layout.get("border_width", 2)),
        "border_height": int(layout.get("border_height", 2)),
        "primary_tileset": layout.get("primary_tileset"),
        "secondary_tileset": layout.get("secondary_tileset"),
        "connections": [
            {"direction": c.get("direction"), "offset": int(c.get("offset", 0)),
             "dest_map": c.get("map")}
            for c in map_json.get("connections", [])
        ],
        "warps": [
            {"warp_id": i, "x": e.get("x"), "y": e.get("y"),
             "dest_map": e.get("dest_map"),
             "dest_warp_id": e.get("dest_warp_id")}
            for i, e in enumerate(map_json.get("warp_events", []))
        ],
    }
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(json.dumps(result, indent=2) + "\n", encoding="utf-8")
    print(f"extracted {map_name}: {width}x{height} -> {out}")
    print("collision defaults to walkable; replace it with project-owned collision data before runtime use")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
