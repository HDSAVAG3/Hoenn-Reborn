#!/usr/bin/env python3
"""Local, non-distributive Emerald ROM compatibility probe.

Reads only metadata/checksums from a user-supplied GBA ROM. It does not copy
Nintendo assets into the project or emit ROM contents.
"""
from __future__ import annotations
import argparse, hashlib, json, struct, zlib
from pathlib import Path

NINTENDO_LOGO = bytes.fromhex(
    "24ffae51699aa2213d84820a84e409ad"
    "11248b31dceca9d2c48a4c7c1a5a6a8f"
    "?"
) if False else None

def u8(b, off): return b[off]
def read_header(p: Path):
    d = p.read_bytes()
    if len(d) < 0xC0:
        raise ValueError("File is too small to be a GBA ROM")
    title = d[0xA0:0xAC].rstrip(b'\0').decode('ascii', 'replace')
    code = d[0xAC:0xB0].decode('ascii', 'replace')
    maker = d[0xB0:0xB2].decode('ascii', 'replace')
    version = d[0xBC]
    complement = d[0xBD]
    # GBA header complement checksum covers 0xA0..0xBC.
    total = 0
    for x in d[0xA0:0xBD]:
        total = (total - x) & 0xFF
    total = (total - 0x19) & 0xFF
    return {
        "file_size": len(d),
        "title": title,
        "game_code": code,
        "maker_code": maker,
        "version": version,
        "header_complement_stored": f"0x{complement:02X}",
        "header_complement_calculated": f"0x{total:02X}",
        "header_complement_valid": complement == total,
        "crc32": f"{zlib.crc32(d) & 0xFFFFFFFF:08X}",
        "sha1": hashlib.sha1(d).hexdigest(),
        "looks_like_emerald_bpee": code == "BPEE" and title == "POKEMON EMER",
    }

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("rom", type=Path)
    ap.add_argument("--json", action="store_true")
    args = ap.parse_args()
    result = read_header(args.rom)
    if args.json:
        print(json.dumps(result, indent=2))
    else:
        print("Hoenn Reborn — Emerald ROM probe")
        for k, v in result.items(): print(f"{k}: {v}")
        print("\nROM assets are intentionally not copied into this project.")

if __name__ == "__main__": main()
