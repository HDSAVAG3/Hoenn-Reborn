#!/usr/bin/env python3
"""Create a metadata-only manifest for a local Emerald ROM."""
import argparse, json
from pathlib import Path
from emerald_rom_probe import read_header

ap=argparse.ArgumentParser()
ap.add_argument('rom', type=Path)
ap.add_argument('output', type=Path)
a=ap.parse_args()
r=read_header(a.rom)
r['source_filename']=a.rom.name
r['asset_policy']='ROM stays external; metadata only'
a.output.write_text(json.dumps(r, indent=2)+"\n", encoding='utf-8')
print(a.output)
