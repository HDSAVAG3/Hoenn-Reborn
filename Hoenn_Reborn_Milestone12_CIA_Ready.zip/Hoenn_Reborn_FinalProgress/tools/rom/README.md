# Local Emerald ROM adapter

`emerald_rom_probe.py` accepts a user-owned/local Pokémon Emerald GBA ROM and verifies the GBA header metadata and checksum. It is intentionally a **probe**, not an asset extractor: the ROM is never copied into the project and no Nintendo graphics/audio/text are emitted.

Example:

```bash
python tools/rom/emerald_rom_probe.py /path/to/Pokemon-Emerald.gba --json
```

A compatible US/EU Emerald header is expected to identify as:

- title: `POKEMON EMER`
- game code: `BPEE`
- version: `0`

The probe also reports file size, GBA header complement validation, CRC32, and SHA-1 so the exact local input can be tracked without bundling it.
