#!/usr/bin/env python3
"""Host-side smoke test for Milestone 6 warp behavior."""
maps={
 'LittlerootTown': {'warp':(38,15,'Route101',1,15)},
 'Route101': {'warp':(1,15,'LittlerootTown',38,15)},
}
name='LittlerootTown'; pos=[38,15]
for _ in range(2):
    w=maps[name]['warp']
    assert tuple(pos)==w[:2]
    name=w[2]; pos=[w[3],w[4]]
print('warp smoke test: PASS')
print('transitions:', 'LittlerootTown -> Route101 -> LittlerootTown')
