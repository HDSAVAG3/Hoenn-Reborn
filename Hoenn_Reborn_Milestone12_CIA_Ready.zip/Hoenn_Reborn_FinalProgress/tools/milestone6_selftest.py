#!/usr/bin/env python3
"""Host-side validation for Milestone 6 map transitions and animation rules."""
from dataclasses import dataclass

@dataclass
class Map:
    id: int
    w: int
    h: int

@dataclass
class Player:
    x: int
    y: int

@dataclass
class Conn:
    direction: str
    offset: int
    dest: int

maps = {1: Map(1, 40, 30), 2: Map(2, 40, 30)}
conns = {(1, "east"): Conn("east", 0, 2), (2, "west"): Conn("west", 0, 1)}

p = Player(39, 15)
p.x += 1
c = conns[(1, "east")]
p = Player(0, 15 - c.offset)
assert p.x == 0 and p.y == 15

p = Player(-1, 12)
c = conns[(2, "west")]
p = Player(39, 12 - c.offset)
assert p.x == 39 and p.y == 12

# Four-frame walk cycle: standing, step, standing, step.
frames = [0]
frame = 0
for _ in range(16):
    frame = (frame + 1) & 3 if (_ + 1) % 4 == 0 else frame
    frames.append(frame)
assert frames[-1] == 0
print("Milestone 6 self-test: PASS")
print("- east/west connection coordinate transforms")
print("- four-frame player animation cycle")
print("- runtime map package remains dependency-free")
