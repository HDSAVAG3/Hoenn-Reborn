from pathlib import Path
import sys, tempfile, os
root=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(root/'tools'))
assert (root/'include/event_flags.h').exists()
assert (root/'include/save_state.h').exists()
assert (root/'include/events.h').exists()
assert 'MILESTONE 7' in (root/'src/overworld.c').read_text()
print('Milestone 8 structure test: PASS')
