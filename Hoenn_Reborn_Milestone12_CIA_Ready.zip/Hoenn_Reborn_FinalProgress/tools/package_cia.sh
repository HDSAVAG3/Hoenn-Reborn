#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
INPUT="${1:-$ROOT/hoenn_reborn.elf}"
OUTPUT="${2:-$ROOT/hoenn_reborn.cia}"
BANNERTOOL="${BANNERTOOL:-${DEVKITPRO:-}/tools/bin/bannertool}"
MAKEROM="${MAKEROM:-${DEVKITPRO:-}/tools/bin/makerom}"
command -v "$BANNERTOOL" >/dev/null 2>&1 || { echo "bannertool is required to create a CIA banner/icon"; exit 1; }
command -v "$MAKEROM" >/dev/null 2>&1 || { echo "makerom is required to create a CIA"; exit 1; }
[ -f "$INPUT" ] || { echo "Missing ELF: $INPUT"; exit 1; }
mkdir -p "$ROOT/build/cia"
"$BANNERTOOL" makebanner -i "$ROOT/assets/banner/banner.png" -o "$ROOT/build/cia/banner.bnr"
"$BANNERTOOL" makesmdh -s "Hoenn Reborn" -l "Hoenn Reborn" -p "Hoenn Reborn" -i "$ROOT/assets/icon/icon.png" -o "$ROOT/build/cia/icon.icn"
"$MAKEROM" -f cia -o "$OUTPUT" -target t -exefslogo -elf "$INPUT" -rsf "$ROOT/assets/hoenn_reborn.rsf" -icon "$ROOT/build/cia/icon.icn" -banner "$ROOT/build/cia/banner.bnr"
echo "Created $OUTPUT"
