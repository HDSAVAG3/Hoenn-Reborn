#!/usr/bin/env python3
"""Generate C runtime data from a hoenn-reborn-map-v2 JSON package.

Usage:
  map_runtime_codegen.py map.json --map-id 101 --ids map_ids.json out.c

map_ids.json is a simple object mapping symbolic map IDs/names to integer IDs,
e.g. {"MAP_ROUTE101": 101, "MAP_LITTLEROOT_TOWN": 1}.
"""
from __future__ import annotations
import argparse, json, re
from pathlib import Path

DIR = {"up":"CONN_NORTH", "down":"CONN_SOUTH", "left":"CONN_WEST", "right":"CONN_EAST",
       "north":"CONN_NORTH", "south":"CONN_SOUTH", "west":"CONN_WEST", "east":"CONN_EAST"}

def ident(s: str) -> str:
    return re.sub(r"[^A-Za-z0-9_]", "_", s)

def resolve(v, ids):
    if isinstance(v, int): return v
    if v in ids: return int(ids[v])
    raise SystemExit(f"destination map {v!r} is missing from the ID manifest")

def arr(values, per=12):
    rows=[]
    for i in range(0,len(values),per): rows.append("    " + ", ".join(str(x) for x in values[i:i+per]))
    return ",\n".join(rows)

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument("map_json")
    ap.add_argument("--map-id", type=int, required=True)
    ap.add_argument("--ids", required=True)
    ap.add_argument("out_c")
    a=ap.parse_args()
    d=json.loads(Path(a.map_json).read_text())
    ids=json.loads(Path(a.ids).read_text())
    name=ident(d.get("name", "map"))
    blocks=d["blocks"]; collision=d["collision"]
    warps=d.get("warps",[]); conns=d.get("connections",[])
    lines=['#include "map_runtime.h"','',f'static const uint16_t {name}_blocks[] = {{',arr(blocks),'};',f'static const uint8_t {name}_collision[] = {{',arr(collision),'};']
    if warps:
        lines += [f'static const RuntimeWarp {name}_warps[] = {{']
        for w in warps:
            dest_warp = w.get("dest_warp_id", 0)
            dest_warp = int(dest_warp) if str(dest_warp).isdigit() else 0
            lines.append("    {" + f"{int(w['x'])}, {int(w['y'])}, {resolve(w['dest_map'], ids)}, {dest_warp}" + "},")
        lines += ['};']
    else: lines += [f'static const RuntimeWarp *{name}_warps = 0;']
    if conns:
        lines += [f'static const RuntimeConnection {name}_connections[] = {{']
        for c in conns:
            direction=DIR.get(c.get("direction"))
            if not direction: raise SystemExit(f'unsupported direction {c.get("direction")!r}')
            lines.append(f'    {{{direction}, {int(c.get("offset",0))}, {resolve(c["dest_map"], ids)}}},')
        lines += ['};']
    else: lines += [f'static const RuntimeConnection *{name}_connections = 0;']
    map_struct = "const RuntimeMap " + name + "_runtime_map = {\n"
    map_struct += f"    {a.map_id}, \"{d.get('name', name)}\",\n"
    map_struct += "    {" + f"{int(d['width'])}, {int(d['height'])}, {name}_blocks, {name}_collision, {int(d['block_count'])}" + "},\n"
    map_struct += f"    {name}_warps, {len(warps)},\n"
    map_struct += f"    {name}_connections, {len(conns)}\n" + "};"
    lines += [map_struct, '']
    Path(a.out_c).write_text("\n".join(lines))
    print(f"generated {a.out_c}: {d.get('name',name)}")

if __name__ == "__main__": main()
