#!/usr/bin/env python3
"""Host-side structural tests for Milestone 7."""
from pathlib import Path
import re

root = Path(__file__).resolve().parents[1]
checks = {
    'include/npc.h': ['typedef struct', 'npc_facing_player', 'npc_blocks_tile'],
    'src/npc.c': ['npc_at', 'npc_blocks_tile', 'npc_facing_player'],
    'include/dialogue.h': ['DialogueState', 'dialogue_open', 'dialogue_update'],
    'src/dialogue.c': ['dialogue_open', 'dialogue_update', 'dialogue_draw'],
    'docs/MILESTONE_7.md': ['NPCs and Dialogue', 'Milestone 8'],
}
for rel, needles in checks.items():
    text = (root / rel).read_text()
    for needle in needles:
        assert needle in text, f'{rel}: missing {needle!r}'

npc = (root / 'src/npc.c').read_text()
assert 'case DIR_UP' in npc and 'case DIR_DOWN' in npc and 'case DIR_LEFT' in npc and 'case DIR_RIGHT' in npc

dlg = (root / 'src/dialogue.c').read_text()
assert 'reveal_all' in dlg and 'dialogue_count' in dlg
print('Milestone 7 self-test: PASS')
