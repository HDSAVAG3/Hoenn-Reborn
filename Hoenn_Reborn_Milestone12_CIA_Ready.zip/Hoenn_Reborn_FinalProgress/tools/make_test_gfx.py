#!/usr/bin/env python3
"""Generate procedural, non-Pokemon graphics for renderer testing."""
from __future__ import annotations
import json, sys
from pathlib import Path

def main():
    root = Path(sys.argv[1]) if len(sys.argv)==2 else Path('examples/gfx_test')
    root.mkdir(parents=True, exist_ok=True)
    colors = [0x7FFF,0x001F,0x03E0,0x7C00,0x4210,0x2529,0x56B5,0x14A5,0x03FF,0x7FE0,0x7C1F,0x421F,0x2108,0x5294,0x2D6B,0x6318]
    (root/'palette.json').write_text(json.dumps({'colors':colors},indent=2)+'\n')
    # 16 procedural tiles, 4bpp, each tile is 32 bytes.
    raw=bytearray()
    for tid in range(16):
        for y in range(8):
            vals=[]
            for x in range(8):
                if tid==0: v=0
                elif tid==1: v=2 if (x+y)%2 else 3
                elif tid==2: v=1 if x in (0,7) or y in (0,7) else 4
                elif tid==3: v=5 if x==y or x+y==7 else 0
                elif tid==4: v=6 if (x-3)**2+(y-3)**2<9 else 0
                elif tid==5: v=7 if y in (2,5) else 0
                elif tid==6: v=8 if x in (2,5) else 0
                elif tid==7: v=9 if (x//2+y//2)%2 else 10
                elif tid==8: v=11 if x==y else 0
                elif tid==9: v=12 if x==3 or y==3 else 0
                elif tid==10: v=13 if (x+y)%3==0 else 0
                elif tid==11: v=14 if x==y or x==7-y else 0
                elif tid==12: v=15 if x in (1,6) and y in (1,6) else 0
                elif tid==13: v=4 if y<4 else 5
                elif tid==14: v=6 if x<4 else 7
                else: v=(x+y)%4+1
                vals.append(v)
            for x in range(0,8,2): raw.append(vals[x] | (vals[x+1]<<4))
    (root/'tiles_4bpp.bin').write_bytes(raw)
    mets=[]
    for i in range(8):
        base=(i*2)%16
        mets.append([{'tile':base},{'tile':(base+1)%16},{'tile':(base+2)%16},{'tile':(base+3)%16}])
    (root/'metatiles.json').write_text(json.dumps({'metatiles':mets},indent=2)+'\n')
    blocks=[]
    for i in range(8): blocks.append([i%8,(i+1)%8,(i+2)%8,(i+3)%8])
    (root/'blocks.json').write_text(json.dumps({'blocks':blocks},indent=2)+'\n')
    w,h=8,6
    ids=[]
    for y in range(h):
        for x in range(w): ids.append((x//2+y//2)%8)
    (root/'map.json').write_text(json.dumps({'format':'hoenn-reborn-map-gfx-test-v1','width':w,'height':h,'blocks':ids},indent=2)+'\n')
    print(f'created test graphics in {root}')

if __name__=='__main__': main()
