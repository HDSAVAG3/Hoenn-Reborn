#pragma once
#include <stdint.h>
#include <stdbool.h>

typedef struct {
    const uint8_t *tiles_4bpp;
    uint32_t tile_bytes;
    const uint16_t *palette_rgb555;
    uint32_t palette_count;
} GbaGfxSource;

bool gfx_decode_tile_4bpp(const GbaGfxSource *src, uint32_t tile_id, uint8_t out[64]);
void gfx_rgb555_to_rgb888(uint16_t c, uint8_t *r, uint8_t *g, uint8_t *b);
