#pragma once

#include <3ds.h>
#include <stdbool.h>
#include "overworld.h"
#include "npc.h"
#include "player_anim.h"
#include "dialogue.h"

/* Milestone 12: software scene renderer for the top 3DS framebuffer.
 * Gameplay visuals live here; the bottom-screen console remains debug-only. */
void scene_renderer_init(void);
void scene_renderer_draw_world(const OverworldMap *map,
                               const NpcMap *npcs,
                               const OverworldPlayer *player,
                               const OverworldCamera *camera,
                               const PlayerAnim *anim,
                               const char *map_name);
void scene_renderer_draw_dialogue(const DialogueState *dialogue);
void scene_renderer_draw_debug_hint(const char *text);
