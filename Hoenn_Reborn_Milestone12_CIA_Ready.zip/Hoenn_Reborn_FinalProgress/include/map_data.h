#pragma once
#include <stdint.h>
#include <stdbool.h>
#include "overworld.h"

/* Runtime-neutral map package produced by the importer. */
typedef struct {
    uint16_t width;
    uint16_t height;
    uint16_t block_count;
    uint16_t *blocks;          /* width * height block IDs */
    uint8_t *collision;        /* width * height, 0 = blocked, non-zero = walkable */
    uint16_t border_width;
    uint16_t border_height;
    uint16_t *border_blocks;
} DecodedMap;

bool map_data_validate(const DecodedMap *map);
bool map_data_to_overworld(const DecodedMap *src, OverworldMap *dst);
