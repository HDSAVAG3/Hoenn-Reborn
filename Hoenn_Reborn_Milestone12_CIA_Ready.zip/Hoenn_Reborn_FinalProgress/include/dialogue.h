#pragma once
#include <stdbool.h>
#include <stdint.h>
#include "npc.h"

typedef struct {
    bool active;
    const Npc *speaker;
    uint8_t line;
    uint8_t char_index;
    uint8_t tick;
    bool reveal_all;
} DialogueState;

void dialogue_init(DialogueState *d);
bool dialogue_open(DialogueState *d, const Npc *npc);
void dialogue_update(DialogueState *d, bool advance_pressed);
void dialogue_draw(const DialogueState *d);
bool dialogue_is_active(const DialogueState *d);
