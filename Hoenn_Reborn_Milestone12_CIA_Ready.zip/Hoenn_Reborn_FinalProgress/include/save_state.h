#pragma once
#include <stdbool.h>
#include <stdint.h>
#include "event_flags.h"
typedef struct { uint32_t magic; uint16_t version; uint16_t map_id; int16_t player_x, player_y; uint8_t facing; uint8_t reserved[3]; EventFlags flags; } SaveState;
void save_state_init(SaveState *s);
bool save_state_capture(SaveState *s,uint16_t map_id,int x,int y,uint8_t facing,const EventFlags *flags);
bool save_state_apply(const SaveState *s,uint16_t *map_id,int *x,int *y,uint8_t *facing,EventFlags *flags);
bool save_state_write_file(const SaveState *s,const char *path);
bool save_state_read_file(SaveState *s,const char *path);
