#pragma once
#include <stdbool.h>
#include <stdint.h>
#include "event_flags.h"
#include "overworld.h"
typedef enum { EVENT_NONE, EVENT_MESSAGE, EVENT_SET_FLAG, EVENT_CLEAR_FLAG } EventType;
typedef struct { EventType type; uint16_t flag_id; const char *const *lines; uint8_t line_count; } WorldEvent;
typedef struct { bool active; const WorldEvent *event; uint16_t index; } EventRunner;
void event_runner_init(EventRunner *r);
bool event_runner_trigger(EventRunner *r,const WorldEvent *e,EventFlags *flags);
bool event_runner_step(EventRunner *r,EventFlags *flags);
