#pragma once
#include <stdbool.h>
#include <stdint.h>
#include "overworld.h"
#include "npc.h"

#define MAP_RUNTIME_MAX_MAPS 32
#define MAP_RUNTIME_MAX_WARPS 64
#define MAP_RUNTIME_MAX_CONNECTIONS 16

typedef enum {
    CONN_NORTH = 0,
    CONN_SOUTH = 1,
    CONN_WEST  = 2,
    CONN_EAST  = 3
} MapConnectionDirection;

typedef struct {
    int x;
    int y;
    int dest_map;
    int dest_warp_id;
} RuntimeWarp;

typedef struct {
    MapConnectionDirection direction;
    int offset;
    int dest_map;
} RuntimeConnection;

typedef struct {
    int id;
    const char *name;
    OverworldMap map;
    const RuntimeWarp *warps;
    uint16_t warp_count;
    const RuntimeConnection *connections;
    uint16_t connection_count;
    NpcMap npcs;
} RuntimeMap;

typedef struct {
    const RuntimeMap *maps;
    uint16_t map_count;
    const RuntimeMap *current;
} MapRuntime;

void map_runtime_init(MapRuntime *rt, const RuntimeMap *maps, uint16_t map_count, int start_map_id);
const RuntimeMap *map_runtime_current(const MapRuntime *rt);
bool map_runtime_load(MapRuntime *rt, int map_id, OverworldPlayer *player);
bool map_runtime_check_warp(MapRuntime *rt, OverworldPlayer *player);
bool map_runtime_check_connection(MapRuntime *rt, OverworldPlayer *player);
