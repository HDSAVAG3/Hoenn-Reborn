#pragma once
#include <3ds.h>

typedef enum {
    UI_NONE = 0,
    UI_POKEMON,
    UI_BAG,
    UI_MAP,
    UI_SAVE,
    UI_POKEDEX,
    UI_OPTIONS
} UiAction;

UiAction touch_ui_update(void);
void touch_ui_draw(void);
