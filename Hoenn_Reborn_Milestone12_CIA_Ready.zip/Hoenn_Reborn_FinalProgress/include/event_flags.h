#pragma once
#include <stdbool.h>
#include <stdint.h>
#define EVENT_FLAG_MAX 256
typedef struct { uint32_t bits[EVENT_FLAG_MAX / 32]; } EventFlags;
void event_flags_init(EventFlags *f);
bool event_flag_get(const EventFlags *f, uint16_t id);
void event_flag_set(EventFlags *f, uint16_t id, bool value);
