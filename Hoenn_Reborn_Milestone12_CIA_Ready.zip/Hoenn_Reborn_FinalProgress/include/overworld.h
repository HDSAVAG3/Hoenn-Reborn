#pragma once
#include <3ds.h>
#include <stdbool.h>
#include <stdint.h>

#define OW_MAX_MAP_W 512
#define OW_MAX_MAP_H 512
#define OW_VIEW_W 20
#define OW_VIEW_H 15

typedef struct NpcMap NpcMap;

typedef enum {
    DIR_UP = 0,
    DIR_DOWN = 1,
    DIR_LEFT = 2,
    DIR_RIGHT = 3
} Facing;

typedef struct {
    uint16_t width;
    uint16_t height;
    const uint16_t *blocks;
    const uint8_t *collision;
    uint16_t block_count;
} OverworldMap;

typedef struct {
    int x;
    int y;
    Facing facing;
} OverworldPlayer;

typedef struct PlayerAnim PlayerAnim;

typedef struct {
    int x;
    int y;
    int view_w;
    int view_h;
} OverworldCamera;

void overworld_init(OverworldPlayer *p);
void overworld_camera_init(OverworldCamera *c);
void overworld_set_map(const OverworldMap *map);
void overworld_set_npcs(const NpcMap *map);
bool overworld_update(OverworldPlayer *p, unsigned keys_down);
void overworld_draw_top(const OverworldPlayer *p, const OverworldCamera *c, const char *map_name, const PlayerAnim *anim);
bool overworld_is_walkable(int x, int y);
void overworld_camera_follow(OverworldCamera *c, const OverworldPlayer *p);
