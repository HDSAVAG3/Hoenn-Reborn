#pragma once
#include <stdint.h>
#include "overworld.h"

typedef struct {
    Facing facing;
    uint8_t frame;       /* 0..2 */
    uint8_t moving;
    uint16_t frame_tick;
} PlayerSpriteState;

void player_sprite_init(PlayerSpriteState *s);
void player_sprite_update(PlayerSpriteState *s, const OverworldPlayer *p, uint16_t delta_ticks);
const char *player_sprite_glyph(const PlayerSpriteState *s);
