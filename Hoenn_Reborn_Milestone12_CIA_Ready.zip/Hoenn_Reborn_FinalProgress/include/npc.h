#pragma once
#include <stdbool.h>
#include <stdint.h>
#include "overworld.h"

#define NPC_MAX_DIALOGUE_LINES 8

typedef struct {
    int x, y;
    Facing facing;
    const char *name;
    const char *const *dialogue;
    uint8_t dialogue_count;
    bool solid;
} Npc;

typedef struct NpcMap {
    const Npc *npcs;
    uint16_t count;
} NpcMap;

bool npc_at(const NpcMap *map, int x, int y, const Npc **out);
bool npc_blocks_tile(const NpcMap *map, int x, int y);
const Npc *npc_facing_player(const NpcMap *map, const OverworldPlayer *player);
