#pragma once
#include <stdbool.h>
#include <stdint.h>
#include "overworld.h"

/* Runtime-neutral player animation state. A sprite sheet is optional; the
 * milestone ships only the state machine and a project-owned test renderer.
 * Frame layout: direction-major, then frame-major. */
typedef struct {
    const uint8_t *pixels;
    uint16_t frame_w;
    uint16_t frame_h;
    uint8_t frame_count;
    uint8_t frames_per_direction;
} PlayerSpriteSheet;

struct PlayerAnim {
    Facing facing;
    uint8_t frame;
    uint8_t tick;
    bool moving;
};

void player_anim_init(PlayerAnim *a, Facing facing);
void player_anim_start_move(PlayerAnim *a, Facing facing);
void player_anim_stop(PlayerAnim *a);
void player_anim_update(PlayerAnim *a);
uint8_t player_anim_frame_index(const PlayerAnim *a);
