#pragma once
#include <stdint.h>
#include "map_runtime.h"
const RuntimeMap *test_maps_get(uint16_t *count);
