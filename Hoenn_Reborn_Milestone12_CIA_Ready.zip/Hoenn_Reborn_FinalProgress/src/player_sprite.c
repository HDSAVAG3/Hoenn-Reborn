#include "player_sprite.h"

void player_sprite_init(PlayerSpriteState *s) {
    if (!s) return;
    s->facing = DIR_DOWN;
    s->frame = 1;
    s->moving = 0;
    s->frame_tick = 0;
}

void player_sprite_update(PlayerSpriteState *s, const OverworldPlayer *p, uint16_t delta_ticks) {
    if (!s || !p) return;
    s->facing = p->facing;
    if (!p->moving) {
        s->moving = 0;
        s->frame = 1;
        s->frame_tick = 0;
        return;
    }
    s->moving = 1;
    s->frame_tick += delta_ticks;
    if (s->frame_tick >= 5) {
        s->frame_tick = 0;
        s->frame = (uint8_t)((s->frame + 1) % 3);
    }
}

const char *player_sprite_glyph(const PlayerSpriteState *s) {
    if (!s) return "@";
    if (s->moving) {
        if (s->facing == DIR_LEFT || s->facing == DIR_RIGHT)
            return (s->frame == 1) ? "@" : (s->frame == 0 ? "/" : "\\");
        return (s->frame == 1) ? "@" : (s->frame == 0 ? "^" : "v");
    }
    switch (s->facing) {
        case DIR_UP: return "^";
        case DIR_LEFT: return "<";
        case DIR_RIGHT: return ">";
        default: return "@";
    }
}
