#include <3ds.h>
#include <stddef.h>
#include "overworld.h"
#include "player_anim.h"
#include "npc.h"
#include "scene_renderer.h"

/* MILESTONE 7 runtime; presentation is now delegated to Milestone 12. */

static const OverworldMap *s_map = NULL;
static unsigned s_move_repeat = 0;
static const NpcMap *s_npcs = NULL;

static uint16_t s_test_blocks[40 * 30];
static uint8_t s_test_collision[40 * 30];

static void make_test_map(void) {
    for (int y = 0; y < 30; ++y) {
        for (int x = 0; x < 40; ++x) {
            const int i = y * 40 + x;
            const bool wall = (x == 0 || y == 0 || x == 39 || y == 29);
            const bool pond = (x >= 10 && x <= 16 && y >= 8 && y <= 13);
            const bool tree = ((x == 25 || x == 26) && y >= 4 && y <= 10);
            s_test_blocks[i] = pond ? 9 : tree ? 12 : (uint16_t)(1 + ((x / 2 + y / 2) % 4));
            s_test_collision[i] = (!wall && !pond && !tree) ? 1 : 0;
        }
    }
}

void overworld_init(OverworldPlayer *p) {
    static OverworldMap test_map;
    make_test_map();
    test_map.width = 40;
    test_map.height = 30;
    test_map.blocks = s_test_blocks;
    test_map.collision = s_test_collision;
    test_map.block_count = 16;
    s_map = &test_map;

    p->x = 5;
    p->y = 5;
    p->facing = DIR_DOWN;
}

void overworld_camera_init(OverworldCamera *c) {
    c->x = 0;
    c->y = 0;
    c->view_w = OW_VIEW_W;
    c->view_h = OW_VIEW_H;
}

void overworld_set_map(const OverworldMap *map) { s_map = map; }
void overworld_set_npcs(const NpcMap *map) { s_npcs = map; }

bool overworld_is_walkable(int x, int y) {
    if (!s_map) return false;
    /* Permit the one-tile step beyond an edge; map_runtime resolves it to a
     * connected map or clamps it when no connection exists. */
    if (x < 0 || y < 0 ||
        x >= (int)s_map->width || y >= (int)s_map->height)
        return (x >= -1 && y >= -1 &&
                x <= (int)s_map->width && y <= (int)s_map->height);
    return s_map->collision[y * s_map->width + x] != 0;
}

static bool try_move(OverworldPlayer *p, int dx, int dy, Facing f) {
    p->facing = f;
    const int nx = p->x + dx;
    const int ny = p->y + dy;
    if (overworld_is_walkable(nx, ny) && !npc_blocks_tile(s_npcs, nx, ny)) {
        p->x = nx;
        p->y = ny;
        return true;
    }
    return false;
}

bool overworld_update(OverworldPlayer *p, unsigned keys_down) {
    bool moved = false;
    if (s_move_repeat > 0) {
        --s_move_repeat;
        return false;
    }
    if (keys_down & KEY_DUP)    moved = try_move(p, 0, -1, DIR_UP) || moved;
    if (keys_down & KEY_DDOWN)  moved = try_move(p, 0,  1, DIR_DOWN) || moved;
    if (keys_down & KEY_DLEFT)  moved = try_move(p, -1, 0, DIR_LEFT) || moved;
    if (keys_down & KEY_DRIGHT) moved = try_move(p, 1,  0, DIR_RIGHT) || moved;
    if (moved) s_move_repeat = 5;
    return moved;
}

void overworld_camera_follow(OverworldCamera *c, const OverworldPlayer *p) {
    if (!s_map) return;
    c->x = p->x - c->view_w / 2;
    c->y = p->y - c->view_h / 2;
    int max_x = (int)s_map->width - c->view_w;
    int max_y = (int)s_map->height - c->view_h;
    if (max_x < 0) max_x = 0;
    if (max_y < 0) max_y = 0;
    if (c->x < 0) c->x = 0;
    if (c->y < 0) c->y = 0;
    if (c->x > max_x) c->x = max_x;
    if (c->y > max_y) c->y = max_y;
}

void overworld_draw_top(const OverworldPlayer *p, const OverworldCamera *c, const char *map_name, const PlayerAnim *anim) {
    scene_renderer_draw_world(s_map, s_npcs, p, c, anim, map_name);
}
