#include <string.h>
#include "dialogue.h"
#include "scene_renderer.h"

#define CHARS_PER_LINE 34

static const char *current_text(const DialogueState *d) {
    if (!d || !d->speaker || !d->speaker->dialogue || d->line >= d->speaker->dialogue_count) return "";
    return d->speaker->dialogue[d->line] ? d->speaker->dialogue[d->line] : "";
}

void dialogue_init(DialogueState *d) { if (d) memset(d, 0, sizeof(*d)); }

bool dialogue_open(DialogueState *d, const Npc *npc) {
    if (!d || !npc || !npc->dialogue_count) return false;
    d->active = true; d->speaker = npc; d->line = 0; d->char_index = 0; d->tick = 0; d->reveal_all = false;
    return true;
}

void dialogue_update(DialogueState *d, bool advance_pressed) {
    if (!d || !d->active) return;
    const char *text = current_text(d);
    uint8_t len = (uint8_t)strlen(text);
    if (advance_pressed) {
        if (!d->reveal_all && d->char_index < len) { d->reveal_all = true; d->char_index = len; return; }
        if (d->line + 1 < d->speaker->dialogue_count) { ++d->line; d->char_index = 0; d->reveal_all = false; return; }
        d->active = false; return;
    }
    if (!d->reveal_all && d->char_index < len) {
        if (++d->tick >= 2) { d->tick = 0; ++d->char_index; }
    }
}

void dialogue_draw(const DialogueState *d) {
    scene_renderer_draw_dialogue(d);
}

bool dialogue_is_active(const DialogueState *d) { return d && d->active; }
