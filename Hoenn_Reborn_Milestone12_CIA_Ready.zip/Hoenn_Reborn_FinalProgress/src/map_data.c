#include "map_data.h"

bool map_data_validate(const DecodedMap *map) {
    if (!map || !map->blocks || !map->collision)
        return false;
    if (map->width == 0 || map->height == 0)
        return false;
    if (map->width > OW_MAX_MAP_W || map->height > OW_MAX_MAP_H)
        return false;
    if (map->block_count == 0)
        return false;
    if (map->border_width && !map->border_height)
        return false;
    if (map->border_height && !map->border_width)
        return false;
    if ((uint32_t)map->border_width * map->border_height && !map->border_blocks)
        return false;
    return true;
}

bool map_data_to_overworld(const DecodedMap *src, OverworldMap *dst) {
    if (!map_data_validate(src) || !dst)
        return false;

    dst->width = src->width;
    dst->height = src->height;
    dst->block_count = src->block_count;
    dst->blocks = src->blocks;
    dst->collision = src->collision;
    return true;
}
