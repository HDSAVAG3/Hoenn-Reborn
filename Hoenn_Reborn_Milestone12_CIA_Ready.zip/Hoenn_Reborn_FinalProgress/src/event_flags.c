#include <string.h>
#include "event_flags.h"
void event_flags_init(EventFlags *f){ if(f) memset(f,0,sizeof(*f)); }
bool event_flag_get(const EventFlags *f,uint16_t id){ return f && id<EVENT_FLAG_MAX && ((f->bits[id>>5]>>(id&31))&1u); }
void event_flag_set(EventFlags *f,uint16_t id,bool value){ if(!f||id>=EVENT_FLAG_MAX)return; uint32_t m=1u<<(id&31); if(value)f->bits[id>>5]|=m; else f->bits[id>>5]&=~m; }
