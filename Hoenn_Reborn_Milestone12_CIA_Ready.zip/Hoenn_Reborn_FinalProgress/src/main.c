#include <3ds.h>
#include <stdio.h>
#include "overworld.h"
#include "touch_ui.h"
#include "map_runtime.h"
#include "player_anim.h"
#include "test_maps.h"
#include "dialogue.h"
#include "event_flags.h"
#include "save_state.h"
#include "events.h"
#include "scene_renderer.h"

typedef enum {
    PANEL_NONE, PANEL_POKEMON, PANEL_BAG, PANEL_MAP,
    PANEL_SAVE, PANEL_POKEDEX, PANEL_OPTIONS
} Panel;

static Panel panel = PANEL_NONE;

static const char *panel_name(Panel p) {
    switch (p) {
        case PANEL_POKEMON: return "Pokemon";
        case PANEL_BAG: return "Bag";
        case PANEL_MAP: return "Map";
        case PANEL_SAVE: return "Save";
        case PANEL_POKEDEX: return "Pokedex";
        case PANEL_OPTIONS: return "Options";
        default: return "Gameplay";
    }
}

int main(void) {
    gfxInitDefault();
    consoleInit(GFX_BOTTOM, NULL);
    scene_renderer_init();

    OverworldPlayer player;
    OverworldCamera camera;
    PlayerAnim anim;
    DialogueState dialogue;
    EventFlags flags;
    EventRunner events;
    SaveState save;
    MapRuntime maps;
    uint16_t map_count = 0;
    const RuntimeMap *map_list = test_maps_get(&map_count);
    overworld_init(&player);
    overworld_camera_init(&camera);
    player_anim_init(&anim, player.facing);
    map_runtime_init(&maps, map_list, map_count, 1);
    dialogue_init(&dialogue);
    event_flags_init(&flags);
    event_runner_init(&events);
    save_state_init(&save);
    overworld_set_map(&maps.current->map);
    overworld_set_npcs(&maps.current->npcs);
    player.x = 5;
    player.y = 15;

    while (aptMainLoop()) {
        hidScanInput();
        u32 down = hidKeysDown();
        u32 held = hidKeysHeld();

        if (down & KEY_A) panel = PANEL_POKEMON;
        if (down & KEY_B) panel = PANEL_BAG;
        if (down & KEY_X) panel = PANEL_MAP;
        if (down & KEY_Y) panel = PANEL_SAVE;
        if (down & KEY_L) panel = PANEL_POKEDEX;
        if (down & KEY_R) panel = PANEL_OPTIONS;
        if (down & KEY_START) break;
        if (down & KEY_SELECT) {
            save_state_capture(&save, (uint16_t)maps.current->id, player.x, player.y, (uint8_t)player.facing, &flags);
            save_state_write_file(&save, "hoenn_reborn.sav");
        }

        UiAction touch = touch_ui_update();
        if (touch != UI_NONE)
            panel = (Panel)touch;

        bool dialogue_was_active = dialogue_is_active(&dialogue);
        if (dialogue_was_active) {
            dialogue_update(&dialogue, (down & KEY_A) != 0);
        } else if (down & KEY_A) {
            const Npc *npc = npc_facing_player(&maps.current->npcs, &player);
            if (npc) dialogue_open(&dialogue, npc);
        }

        bool moved = dialogue_is_active(&dialogue) ? false : overworld_update(&player, held);
        if (moved) player_anim_start_move(&anim, player.facing);
        else player_anim_stop(&anim);
        player_anim_update(&anim);

        if (map_runtime_check_warp(&maps, &player) || map_runtime_check_connection(&maps, &player)) {
            overworld_set_map(&maps.current->map);
            overworld_set_npcs(&maps.current->npcs);
            player_anim_stop(&anim);
            dialogue_init(&dialogue);
        }

        overworld_camera_follow(&camera, &player);
        overworld_draw_top(&player, &camera, maps.current ? maps.current->name : "(none)", &anim);
        dialogue_draw(&dialogue);
        touch_ui_draw();

        consoleSelect(&consoles[1]);
        printf("\x1b[23;2HFlag 0: %s  | SELECT: Save", event_flag_get(&flags, 0) ? "ON " : "OFF");
        printf("\x1b[22;2HActive: %-10s", panel_name(panel));

        gfxFlushBuffers();
        gfxSwapBuffers();
        gspWaitForVBlank();
    }

    gfxExit();
    return 0;
}
