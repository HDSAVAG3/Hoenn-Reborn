#include "player_anim.h"

#define WALK_TICKS_PER_FRAME 4

void player_anim_init(PlayerAnim *a, Facing facing) {
    if (!a) return;
    a->facing = facing;
    a->frame = 0;
    a->tick = 0;
    a->moving = false;
}

void player_anim_start_move(PlayerAnim *a, Facing facing) {
    if (!a) return;
    if (a->facing != facing) {
        a->facing = facing;
        a->frame = 0;
        a->tick = 0;
    }
    a->moving = true;
}

void player_anim_stop(PlayerAnim *a) {
    if (!a) return;
    a->moving = false;
    a->frame = 0;
    a->tick = 0;
}

void player_anim_update(PlayerAnim *a) {
    if (!a || !a->moving) return;
    if (++a->tick < WALK_TICKS_PER_FRAME) return;
    a->tick = 0;
    /* 0 = standing, 1 = left step, 2 = standing, 3 = right step. */
    a->frame = (uint8_t)((a->frame + 1) & 3);
}

uint8_t player_anim_frame_index(const PlayerAnim *a) {
    if (!a) return 0;
    return (uint8_t)(a->facing * 4 + a->frame);
}
