#include "gfx_renderer.h"

bool gfx_decode_tile_4bpp(const GbaGfxSource *src, uint32_t tile_id, uint8_t out[64]) {
    if (!src || !out || !src->tiles_4bpp) return false;
    uint32_t off = tile_id * 32;
    if (off + 32 > src->tile_bytes) return false;
    for (int y=0; y<8; ++y) {
        for (int x=0; x<8; x+=2) {
            uint8_t b = src->tiles_4bpp[off + y*4 + x/2];
            out[y*8+x] = b & 0x0F;
            out[y*8+x+1] = b >> 4;
        }
    }
    return true;
}

void gfx_rgb555_to_rgb888(uint16_t c, uint8_t *r, uint8_t *g, uint8_t *b) {
    if (r) *r = (uint8_t)(((c & 31) * 255) / 31);
    if (g) *g = (uint8_t)((((c >> 5) & 31) * 255) / 31);
    if (b) *b = (uint8_t)((((c >> 10) & 31) * 255) / 31);
}
