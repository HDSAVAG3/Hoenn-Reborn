#include <3ds.h>
#include <stdint.h>
#include <string.h>
#include "scene_renderer.h"

#define SCREEN_W 400
#define SCREEN_H 240
#define TILE 16
#define VIEW_W 25
#define VIEW_H 15

#define RGB565(r,g,b) (u16)((((r) & 0xF8) << 8) | (((g) & 0xFC) << 3) | ((b) >> 3))

static u16 *s_fb;

static inline u16 *pixel_ptr(int x, int y) {
    if (!s_fb || x < 0 || x >= SCREEN_W || y < 0 || y >= SCREEN_H) return 0;
    /* 3DS framebuffers are sideways in memory: X is the major stride. */
    return &s_fb[x * SCREEN_H + (SCREEN_H - 1 - y)];
}

static void clear(u16 color) {
    if (!s_fb) return;
    for (int x = 0; x < SCREEN_W; ++x)
        for (int y = 0; y < SCREEN_H; ++y)
            s_fb[x * SCREEN_H + (SCREEN_H - 1 - y)] = color;
}

static void rect(int x, int y, int w, int h, u16 color) {
    if (!s_fb || w <= 0 || h <= 0) return;
    int x0 = x < 0 ? 0 : x;
    int y0 = y < 0 ? 0 : y;
    int x1 = x + w > SCREEN_W ? SCREEN_W : x + w;
    int y1 = y + h > SCREEN_H ? SCREEN_H : y + h;
    for (int py = y0; py < y1; ++py)
        for (int px = x0; px < x1; ++px)
            *pixel_ptr(px, py) = color;
}

static void outline(int x, int y, int w, int h, u16 color) {
    rect(x, y, w, 1, color);
    rect(x, y + h - 1, w, 1, color);
    rect(x, y, 1, h, color);
    rect(x + w - 1, y, 1, h, color);
}

/* Compact 5x7 font. Each byte contains one row, bit 4 is the left pixel. */
static const uint8_t font_5x7[][7] = {
    /* 0-9 */
    {0x0E,0x11,0x13,0x15,0x19,0x11,0x0E}, {0x04,0x0C,0x04,0x04,0x04,0x04,0x0E},
    {0x0E,0x11,0x01,0x02,0x04,0x08,0x1F}, {0x1E,0x01,0x01,0x0E,0x01,0x01,0x1E},
    {0x02,0x06,0x0A,0x12,0x1F,0x02,0x02}, {0x1F,0x10,0x1E,0x01,0x01,0x11,0x0E},
    {0x06,0x08,0x10,0x1E,0x11,0x11,0x0E}, {0x1F,0x01,0x02,0x04,0x08,0x08,0x08},
    {0x0E,0x11,0x11,0x0E,0x11,0x11,0x0E}, {0x0E,0x11,0x11,0x0F,0x01,0x02,0x0C},
    /* A-Z */
    {0x0E,0x11,0x11,0x1F,0x11,0x11,0x11}, {0x1E,0x11,0x11,0x1E,0x11,0x11,0x1E},
    {0x0E,0x11,0x10,0x10,0x10,0x11,0x0E}, {0x1E,0x11,0x11,0x11,0x11,0x11,0x1E},
    {0x1F,0x10,0x10,0x1E,0x10,0x10,0x1F}, {0x1F,0x10,0x10,0x1E,0x10,0x10,0x10},
    {0x0E,0x11,0x10,0x17,0x11,0x11,0x0F}, {0x11,0x11,0x11,0x1F,0x11,0x11,0x11},
    {0x0E,0x04,0x04,0x04,0x04,0x04,0x0E}, {0x07,0x02,0x02,0x02,0x12,0x12,0x0C},
    {0x11,0x12,0x14,0x18,0x14,0x12,0x11}, {0x10,0x10,0x10,0x10,0x10,0x10,0x1F},
    {0x11,0x1B,0x15,0x15,0x11,0x11,0x11}, {0x11,0x19,0x19,0x15,0x13,0x13,0x11},
    {0x0E,0x11,0x11,0x11,0x11,0x11,0x0E}, {0x1E,0x11,0x11,0x1E,0x10,0x10,0x10},
    {0x0E,0x11,0x11,0x11,0x15,0x12,0x0D}, {0x1E,0x11,0x11,0x1E,0x14,0x12,0x11},
    {0x0F,0x10,0x10,0x0E,0x01,0x01,0x1E}, {0x1F,0x04,0x04,0x04,0x04,0x04,0x04},
    {0x11,0x11,0x11,0x11,0x11,0x11,0x0E}, {0x11,0x11,0x11,0x11,0x0A,0x0A,0x04},
    {0x11,0x11,0x11,0x15,0x15,0x1B,0x11}, {0x11,0x0A,0x04,0x04,0x0A,0x11,0x11},
    {0x11,0x11,0x0A,0x04,0x04,0x04,0x04}, {0x1F,0x01,0x02,0x04,0x08,0x10,0x1F},
};

static const uint8_t *glyph(char c) {
    if (c >= '0' && c <= '9') return font_5x7[(int)(c - '0')];
    if (c >= 'a' && c <= 'z') c = (char)(c - 'a' + 'A');
    if (c >= 'A' && c <= 'Z') return font_5x7[10 + (c - 'A')];
    return NULL;
}

static void draw_char(int x, int y, char c, int scale, u16 color) {
    if (c == ' ') return;
    const uint8_t *g = glyph(c);
    if (!g) {
        if (c == '.') rect(x + 2 * scale, y + 6 * scale, scale, scale, color);
        else if (c == ':') { rect(x + 2*scale, y + 2*scale, scale, scale, color); rect(x + 2*scale, y + 5*scale, scale, scale, color); }
        else if (c == '-') rect(x, y + 3*scale, 5*scale, scale, color);
        else if (c == '!') { rect(x + 2*scale, y, scale, 5*scale, color); rect(x + 2*scale, y + 6*scale, scale, scale, color); }
        else if (c == '?') { rect(x + scale, y, 3*scale, scale, color); rect(x + 3*scale, y + scale, scale, 2*scale, color); rect(x + 2*scale, y + 3*scale, scale, scale, color); rect(x + 2*scale, y + 5*scale, scale, 2*scale, color); }
        return;
    }
    for (int row = 0; row < 7; ++row)
        for (int col = 0; col < 5; ++col)
            if (g[row] & (1 << (4 - col)))
                rect(x + col*scale, y + row*scale, scale, scale, color);
}

static void text(int x, int y, const char *s, int scale, u16 color) {
    if (!s) return;
    for (size_t i = 0; s[i] && x < SCREEN_W - 8; ++i, x += 6 * scale)
        draw_char(x, y, s[i], scale, color);
}

static u16 tile_color(uint16_t id) {
    switch (id % 8) {
        case 0: return RGB565(70, 145, 78);   /* grass */
        case 1: return RGB565(88, 160, 82);
        case 2: return RGB565(125, 175, 92);
        case 3: return RGB565(172, 155, 92);  /* path */
        case 4: return RGB565(100, 172, 100);
        case 5: return RGB565(48, 125, 190);   /* water */
        case 6: return RGB565(56, 112, 170);
        default: return RGB565(62, 135, 72);   /* trees/rough */
    }
}

static void draw_tile(int sx, int sy, uint16_t id) {
    u16 base = tile_color(id);
    rect(sx, sy, TILE, TILE, base);
    switch (id % 8) {
        case 5:
        case 6:
            rect(sx + 2, sy + 4, 5, 1, RGB565(140, 210, 230));
            rect(sx + 9, sy + 10, 4, 1, RGB565(120, 195, 225));
            break;
        case 7:
            rect(sx + 6, sy + 2, 4, 7, RGB565(34, 102, 48));
            rect(sx + 3, sy + 5, 10, 6, RGB565(42, 116, 53));
            rect(sx + 7, sy + 11, 2, 5, RGB565(102, 72, 40));
            break;
        default:
            rect(sx + 1, sy + 14, 14, 1, RGB565(50, 110, 60));
            if ((id & 1) == 0) rect(sx + 3, sy + 4, 2, 2, RGB565(205, 205, 105));
            break;
    }
}

static void draw_actor(int cx, int cy, Facing facing, uint8_t frame, bool npc) {
    int bob = (!npc && frame != 0) ? ((frame & 1) ? -1 : 1) : 0;
    u16 outline_color = RGB565(28, 28, 34);
    u16 shirt = npc ? RGB565(205, 80, 55) : RGB565(245, 225, 75);
    u16 pants = npc ? RGB565(60, 80, 150) : RGB565(55, 80, 155);
    u16 skin = RGB565(245, 185, 145);

    rect(cx - 6, cy - 10 + bob, 12, 10, outline_color);
    rect(cx - 5, cy - 9 + bob, 10, 8, skin);
    rect(cx - 6, cy - 10 + bob, 12, 3, npc ? RGB565(80, 55, 45) : RGB565(42, 42, 48));
    rect(cx - 6, cy - 1 + bob, 12, 7, shirt);
    rect(cx - 5, cy + 6 + bob, 10, 7, pants);
    rect(cx - 6, cy + 13 + bob, 5, 2, outline_color);
    rect(cx + 1, cy + 13 + bob, 5, 2, outline_color);

    if (facing == DIR_LEFT) rect(cx - 6, cy - 6 + bob, 2, 2, RGB565(35,35,35));
    if (facing == DIR_RIGHT) rect(cx + 4, cy - 6 + bob, 2, 2, RGB565(35,35,35));
}

void scene_renderer_init(void) {
    gfxSetScreenFormat(GFX_TOP, GSP_RGB565_OES);
    gfxSetDoubleBuffering(GFX_TOP, true);
}

void scene_renderer_draw_world(const OverworldMap *map,
                               const NpcMap *npcs,
                               const OverworldPlayer *player,
                               const OverworldCamera *camera,
                               const PlayerAnim *anim,
                               const char *map_name) {
    s_fb = (u16*)gfxGetFramebuffer(GFX_TOP, GFX_LEFT, NULL, NULL);
    clear(RGB565(35, 45, 65));
    if (!map || !player || !camera) return;

    const int view_w = VIEW_W;
    const int view_h = VIEW_H;
    const int origin_x = (SCREEN_W - view_w * TILE) / 2;
    const int origin_y = 0;

    for (int sy = 0; sy < view_h; ++sy) {
        for (int sx = 0; sx < view_w; ++sx) {
            int mx = camera->x + sx;
            int my = camera->y + sy;
            int px = origin_x + sx * TILE;
            int py = origin_y + sy * TILE;
            if (mx >= 0 && my >= 0 && mx < (int)map->width && my < (int)map->height)
                draw_tile(px, py, map->blocks[my * map->width + mx]);
            else
                rect(px, py, TILE, TILE, RGB565(30, 40, 55));
        }
    }

    /* NPCs render above terrain and below the player. */
    if (npcs && npcs->npcs) {
        for (uint16_t i = 0; i < npcs->count; ++i) {
            const Npc *n = &npcs->npcs[i];
            int sx = n->x - camera->x;
            int sy = n->y - camera->y;
            if (sx >= 0 && sx < view_w && sy >= 0 && sy < view_h)
                draw_actor(origin_x + sx*TILE + TILE/2, sy*TILE + 8, n->facing, 0, true);
        }
    }

    int psx = player->x - camera->x;
    int psy = player->y - camera->y;
    if (psx >= -1 && psx < view_w && psy >= -1 && psy < view_h) {
        uint8_t frame = anim ? player_anim_frame_index(anim) & 3 : 0;
        draw_actor(origin_x + psx*TILE + TILE/2, psy*TILE + 8, player->facing, frame, false);
    }

    /* Minimal gameplay HUD: not the debug console. */
    rect(0, 0, 400, 18, RGB565(20, 25, 35));
    text(7, 5, map_name ? map_name : "HOENN REBORN", 1, RGB565(245,245,245));
    rect(315, 3, 77, 12, RGB565(35, 60, 80));
    text(321, 6, "FIELD", 1, RGB565(190, 225, 245));

    /* Subtle camera/player focus marker. */
    int pcx = origin_x + psx*TILE + TILE/2;
    int pcy = psy*TILE + 8;
    if (psx >= 0 && psx < view_w && psy >= 0 && psy < view_h)
        outline(pcx - 9, pcy - 16, 18, 30, RGB565(255, 240, 145));
}

void scene_renderer_draw_dialogue(const DialogueState *d) {
    if (!d || !d->active || !d->speaker) return;
    const char *full = (d->line < d->speaker->dialogue_count) ? d->speaker->dialogue[d->line] : "";
    if (!full) full = "";

    char visible[128];
    size_t n = strlen(full);
    if (n > sizeof(visible)-1) n = sizeof(visible)-1;
    size_t shown = d->char_index < n ? d->char_index : n;
    memcpy(visible, full, shown);
    visible[shown] = '\0';

    rect(18, 177, 364, 52, RGB565(18, 22, 30));
    outline(18, 177, 364, 52, RGB565(240, 235, 195));
    rect(28, 184, 100, 14, RGB565(65, 85, 115));
    text(34, 188, d->speaker->name ? d->speaker->name : "NPC", 1, RGB565(255,255,255));
    text(29, 204, visible, 1, RGB565(250,250,240));
    if (shown < n) {
        rect(365, 216, 5, 3, RGB565(255, 240, 100));
    } else {
        text(350, 216, "A", 1, RGB565(255,240,100));
    }
}

void scene_renderer_draw_debug_hint(const char *hint) {
    (void)hint;
}
