#include "events.h"
void event_runner_init(EventRunner*r){if(r){r->active=false;r->event=0;r->index=0;}}
bool event_runner_trigger(EventRunner*r,const WorldEvent*e,EventFlags*f){if(!r||!e)return false;r->event=e;r->index=0;r->active=true;if(e->type==EVENT_SET_FLAG)event_flag_set(f,e->flag_id,true);if(e->type==EVENT_CLEAR_FLAG)event_flag_set(f,e->flag_id,false);return true;}
bool event_runner_step(EventRunner*r,EventFlags*f){(void)f;if(!r||!r->active)return false;if(!r->event||r->event->type!=EVENT_MESSAGE){r->active=false;return true;}if(++r->index>=r->event->line_count)r->active=false;return true;}
