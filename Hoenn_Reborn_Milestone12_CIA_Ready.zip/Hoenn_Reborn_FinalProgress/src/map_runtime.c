#include <stddef.h>
#include "map_runtime.h"

static const RuntimeMap *find_map(const MapRuntime *rt, int id) {
    if (!rt || !rt->maps) return NULL;
    for (uint16_t i = 0; i < rt->map_count; ++i)
        if (rt->maps[i].id == id) return &rt->maps[i];
    return NULL;
}

static const RuntimeWarp *find_warp(const RuntimeMap *map, int id) {
    if (!map || !map->warps || id < 0 || id >= (int)map->warp_count) return NULL;
    return &map->warps[id];
}

void map_runtime_init(MapRuntime *rt, const RuntimeMap *maps, uint16_t map_count, int start_map_id) {
    if (!rt) return;
    rt->maps = maps;
    rt->map_count = map_count;
    rt->current = find_map(rt, start_map_id);
}

const RuntimeMap *map_runtime_current(const MapRuntime *rt) {
    return rt ? rt->current : NULL;
}

bool map_runtime_load(MapRuntime *rt, int map_id, OverworldPlayer *player) {
    if (!rt) return false;
    const RuntimeMap *next = find_map(rt, map_id);
    if (!next) return false;
    rt->current = next;
    if (player) {
        player->x = (int)next->map.width / 2;
        player->y = (int)next->map.height / 2;
    }
    return true;
}

bool map_runtime_check_warp(MapRuntime *rt, OverworldPlayer *player) {
    if (!rt || !rt->current || !player) return false;
    for (uint16_t i = 0; i < rt->current->warp_count; ++i) {
        const RuntimeWarp *w = &rt->current->warps[i];
        if (player->x != w->x || player->y != w->y) continue;
        const RuntimeMap *dest = find_map(rt, w->dest_map);
        if (!dest) return false;
        const RuntimeWarp *dest_warp = find_warp(dest, w->dest_warp_id);
        rt->current = dest;
        if (dest_warp) {
            player->x = dest_warp->x;
            player->y = dest_warp->y;
        } else {
            player->x = (int)dest->map.width / 2;
            player->y = (int)dest->map.height / 2;
        }
        return true;
    }
    return false;
}

static const RuntimeConnection *find_connection(const RuntimeMap *map, MapConnectionDirection dir) {
    if (!map || !map->connections) return NULL;
    for (uint16_t i = 0; i < map->connection_count; ++i)
        if (map->connections[i].direction == dir) return &map->connections[i];
    return NULL;
}

bool map_runtime_check_connection(MapRuntime *rt, OverworldPlayer *player) {
    if (!rt || !rt->current || !player) return false;

    MapConnectionDirection dir;
    if (player->x < 0) dir = CONN_WEST;
    else if (player->x >= (int)rt->current->map.width) dir = CONN_EAST;
    else if (player->y < 0) dir = CONN_NORTH;
    else if (player->y >= (int)rt->current->map.height) dir = CONN_SOUTH;
    else return false;

    const RuntimeConnection *conn = find_connection(rt->current, dir);
    if (!conn) {
        /* No connected map: clamp at the edge. */
        if (player->x < 0) player->x = 0;
        if (player->x >= (int)rt->current->map.width) player->x = rt->current->map.width - 1;
        if (player->y < 0) player->y = 0;
        if (player->y >= (int)rt->current->map.height) player->y = rt->current->map.height - 1;
        return false;
    }

    const RuntimeMap *dest = find_map(rt, conn->dest_map);
    if (!dest) return false;

    int old_x = player->x;
    int old_y = player->y;
    rt->current = dest;

    /* These formulas mirror Emerald's connection-offset model: north/south
     * offset the X coordinate; east/west offset Y. */
    switch (dir) {
        case CONN_NORTH:
            player->x = old_x - conn->offset;
            player->y = (int)dest->map.height - 1;
            break;
        case CONN_SOUTH:
            player->x = old_x - conn->offset;
            player->y = 0;
            break;
        case CONN_WEST:
            player->x = (int)dest->map.width - 1;
            player->y = old_y - conn->offset;
            break;
        case CONN_EAST:
            player->x = 0;
            player->y = old_y - conn->offset;
            break;
    }

    if (player->x < 0) player->x = 0;
    if (player->y < 0) player->y = 0;
    if (player->x >= (int)dest->map.width) player->x = dest->map.width - 1;
    if (player->y >= (int)dest->map.height) player->y = dest->map.height - 1;
    return true;
}
