#include "npc.h"

bool npc_at(const NpcMap *map, int x, int y, const Npc **out) {
    if (out) *out = 0;
    if (!map || !map->npcs) return false;
    for (uint16_t i = 0; i < map->count; ++i) {
        if (map->npcs[i].x == x && map->npcs[i].y == y) {
            if (out) *out = &map->npcs[i];
            return true;
        }
    }
    return false;
}

bool npc_blocks_tile(const NpcMap *map, int x, int y) {
    const Npc *n = 0;
    return npc_at(map, x, y, &n) && n && n->solid;
}

const Npc *npc_facing_player(const NpcMap *map, const OverworldPlayer *player) {
    if (!map || !player) return 0;
    int x = player->x, y = player->y;
    switch (player->facing) {
        case DIR_UP: --y; break;
        case DIR_DOWN: ++y; break;
        case DIR_LEFT: --x; break;
        case DIR_RIGHT: ++x; break;
    }
    const Npc *n = 0;
    return npc_at(map, x, y, &n) ? n : 0;
}
