#include <3ds.h>
#include <stdio.h>
#include "touch_ui.h"

UiAction touch_ui_update(void) {
    touchPosition t;
    hidTouchRead(&t);

    if (t.px >= 320 || t.py >= 240)
        return UI_NONE;

    /* 2 columns x 3 rows, each 160x80 pixels. */
    int col = t.px / 160;
    int row = t.py / 80;
    int i = row * 2 + col;

    if (row >= 0 && row < 3 && col >= 0 && col < 2)
        return (UiAction)(UI_POKEMON + i);

    return UI_NONE;
}

void touch_ui_draw(void) {
    consoleSelect(&consoles[1]);
    consoleClear();

    printf("\x1b[1;2HHOENN REBORN");
    printf("\x1b[3;2HTOUCH DASHBOARD");
    printf("\x1b[6;2H[ Pokemon ]     [ Bag ]");
    printf("\x1b[10;2H[ Map ]         [ Save ]");
    printf("\x1b[14;2H[ Pokedex ]     [ Options ]");
    printf("\x1b[20;2HTouch a panel");
}
