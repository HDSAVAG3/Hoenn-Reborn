#include <stdio.h>
#include <string.h>
#include "save_state.h"
#define SAVE_MAGIC 0x48524E31u
#define SAVE_VERSION 1
void save_state_init(SaveState*s){if(!s)return;memset(s,0,sizeof(*s));s->magic=SAVE_MAGIC;s->version=SAVE_VERSION;event_flags_init(&s->flags);}
bool save_state_capture(SaveState*s,uint16_t id,int x,int y,uint8_t facing,const EventFlags*f){if(!s)return false;save_state_init(s);s->map_id=id;s->player_x=(int16_t)x;s->player_y=(int16_t)y;s->facing=facing;if(f)s->flags=*f;return true;}
bool save_state_apply(const SaveState*s,uint16_t*id,int*x,int*y,uint8_t*facing,EventFlags*flags){if(!s||s->magic!=SAVE_MAGIC||s->version!=SAVE_VERSION)return false;if(id)*id=s->map_id;if(x)*x=s->player_x;if(y)*y=s->player_y;if(facing)*facing=s->facing;if(flags)*flags=s->flags;return true;}
bool save_state_write_file(const SaveState*s,const char*path){if(!s||!path)return false;FILE*f=fopen(path,"wb");if(!f)return false;bool ok=fwrite(s,sizeof(*s),1,f)==1;fclose(f);return ok;}
bool save_state_read_file(SaveState*s,const char*path){if(!s||!path)return false;FILE*f=fopen(path,"rb");if(!f)return false;bool ok=fread(s,sizeof(*s),1,f)==1;fclose(f);return ok&&s->magic==SAVE_MAGIC&&s->version==SAVE_VERSION;}
