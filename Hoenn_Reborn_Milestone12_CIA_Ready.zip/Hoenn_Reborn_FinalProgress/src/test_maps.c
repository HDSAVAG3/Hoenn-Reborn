#include "map_runtime.h"

static uint16_t map_a_blocks[40 * 30];
static uint8_t map_a_collision[40 * 30];
static uint16_t map_b_blocks[40 * 30];
static uint8_t map_b_collision[40 * 30];

static const RuntimeWarp map_a_warps[] = {
    { 35, 15, 2, 0 }
};
static const RuntimeWarp map_b_warps[] = {
    { 4, 15, 1, 0 }
};

static const RuntimeConnection map_a_connections[] = {
    { CONN_EAST, 0, 2 }
};
static const RuntimeConnection map_b_connections[] = {
    { CONN_WEST, 0, 1 }
};

static const char *route_dialogue[] = {
    "Welcome to Hoenn Reborn!",
    "Press A while facing me to talk.",
    "The next milestone will add richer events.",
};
static const char *town_dialogue[] = {
    "This is the Littleroot test map.",
    "Warps and NPC interactions are working!",
};
static const Npc map_a_npcs[] = {
    { 8, 15, DIR_DOWN, "Guide", route_dialogue, 3, true },
};
static const Npc map_b_npcs[] = {
    { 20, 15, DIR_LEFT, "Researcher", town_dialogue, 2, true },
};

static void make_map(uint16_t *blocks, uint8_t *collision, int variant) {
    for (int y = 0; y < 30; ++y) {
        for (int x = 0; x < 40; ++x) {
            int i = y * 40 + x;
            bool wall = (x == 0 || y == 0 || x == 39 || y == 29);
            bool obstacle = variant == 1
                ? ((x >= 10 && x <= 16 && y >= 8 && y <= 13) || (x == 25 && y >= 4 && y <= 10))
                : ((x >= 20 && x <= 25 && y >= 16 && y <= 22) || (x == 8 && y >= 4 && y <= 9));
            blocks[i] = obstacle ? (uint16_t)(8 + variant) : (uint16_t)(1 + ((x / 2 + y / 2 + variant) % 4));
            collision[i] = (!wall && !obstacle) ? 1 : 0;
        }
    }
    /* Make the connection lane traversable. */
    for (int y = 13; y <= 17; ++y) {
        collision[y * 40 + 0] = 1;
        collision[y * 40 + 39] = 1;
    }
}

const RuntimeMap *test_maps_get(uint16_t *count) {
    static RuntimeMap maps[2];
    static bool initialized = false;
    if (!initialized) {
        make_map(map_a_blocks, map_a_collision, 1);
        make_map(map_b_blocks, map_b_collision, 2);
        maps[0] = (RuntimeMap){1, "Route 101", {40, 30, map_a_blocks, map_a_collision, 16}, map_a_warps, 1, map_a_connections, 1, {map_a_npcs, 1}};
        maps[1] = (RuntimeMap){2, "Littleroot", {40, 30, map_b_blocks, map_b_collision, 16}, map_b_warps, 1, map_b_connections, 1, {map_b_npcs, 1}};
        initialized = true;
    }
    if (count) *count = 2;
    return maps;
}
