# Build Hoenn Reborn for a modded Nintendo 3DS

This project is configured to produce both:

- `hoenn_reborn.3dsx` for Homebrew Launcher
- `hoenn_reborn.cia` for installation with FBI/another CIA installer

The CIA is built from the native 3DS ELF with `makerom`; it is not a renamed
or converted `.3dsx`. The workflow installs the current Linux `makerom` and
`bannertool` releases before packaging.

## GitHub Actions

1. Create a GitHub repository and upload this project.
2. Push to `main`/`master`, or open **Actions → Build Hoenn Reborn 3DSX and CIA → Run workflow**.
3. Wait for the workflow to finish.
4. Download the **hoenn-reborn-cia** artifact.
5. Extract `hoenn_reborn.cia`.
6. Copy it to the 3DS SD card and install it with FBI.

The project does **not** embed or redistribute the supplied Pokémon Emerald ROM.

## Local build

With devkitPro/devkitARM, libctru, makerom and bannertool installed:

```sh
make clean
make
make cia
```

The CIA output is `hoenn_reborn.cia`.

## Current scope

The Milestone 12 native 3DS executable is the graphical-scene prototype:
map renderer, camera, player, NPCs, dialogue and debug/gameplay separation.
The Emerald ROM remains an external source for future data extraction/import.
