# 3DS test checklist

Expected controls:

- D-pad: move the player
- A: interact with the NPC in front of the player / advance dialogue
- B: open the Bag panel state
- X: open the Map panel state
- Y: trigger the Save action
- L/R: switch panel state
- SELECT: write `hoenn_reborn.sav`
- START: exit

The top screen is the graphical gameplay scene. The bottom screen remains the
debug console.
