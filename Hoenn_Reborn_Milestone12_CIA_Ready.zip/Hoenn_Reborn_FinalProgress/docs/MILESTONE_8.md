# Milestone 8 — Events, Save State, and Dialogue Foundation

Adds a reusable world-event layer, 256 persistent event flags, a versioned binary save-state structure, and a small event runner. Existing dialogue remains compatible; the event system is intentionally separate so scripted sequences can later coordinate NPC movement, dialogue, map transitions, and flags.

Save data is local runtime state only. No Nintendo assets are included.
