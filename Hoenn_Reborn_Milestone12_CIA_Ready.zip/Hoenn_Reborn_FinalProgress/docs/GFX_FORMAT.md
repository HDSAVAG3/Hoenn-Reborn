# Hoenn Reborn normalized graphics format

The normalized graphics layer deliberately separates source-specific Emerald
parsing from rendering. This makes the renderer usable with user-supplied
source data without embedding Nintendo assets in the repository.

## Tile data

`tiles_4bpp.bin` contains 8x8 GBA tiles. Each tile is 32 bytes: two 4-bit
palette indices per byte, four bytes per row.

## Palette

`palette.json` contains 16 RGB555 values. The renderer converts them to 8-bit
RGB at output time.

## Metatiles

`metatiles.json` contains four tile records per 16x16 metatile, in row-major
order. A record has `tile` and optional `flip_x` / `flip_y` fields.

## Blocks

`blocks.json` contains four metatile IDs per 32x32 block, in row-major order.

## Map

`map.json` contains the block ID grid. It is independent from the source
Emerald map JSON and can therefore be validated and tested on its own.
