# Milestone 12 — Actual 3DS Graphical Scene

Milestone 12 replaces the top-screen console map with a real framebuffer-backed
scene renderer. The runtime remains renderer-neutral at the gameplay layer while
all presentation code is isolated in `scene_renderer.c`.

## Completed

- Top screen uses an RGB565 3DS framebuffer instead of the text console.
- 25x15 tile viewport at 16x16 pixels, matching the top-screen 400x240 logical area.
- Camera clipping and edge handling remain owned by the overworld camera.
- Project-owned procedural terrain visuals for grass, paths, water, and trees.
- Player sprite rendered as a small directional animated character.
- NPCs rendered as separate world actors.
- Gameplay HUD and dialogue box are drawn on the top framebuffer.
- Bottom screen remains a console-only debug/dashboard surface, separating debug
  diagnostics from gameplay presentation.
- No Nintendo ROM bytes or Pokémon graphics are copied into the project.

## Build

A configured devkitPro/devkitARM/libctru environment is still required for a real
`.3dsx` or `.cia` build. This workspace does not contain that SDK runtime, so the
source can be validated here but cannot honestly be claimed to produce a 3DS
binary locally.

Run the host-side regression suite with:

```bash
python3 tools/milestone12_selftest.py
```
