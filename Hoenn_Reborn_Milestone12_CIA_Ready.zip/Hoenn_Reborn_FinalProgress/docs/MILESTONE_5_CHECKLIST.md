# Milestone 5 verification

- [x] GBA 4bpp tile decoder
- [x] RGB555 -> RGB888 conversion
- [x] 8x8 tile composition
- [x] 16x16 metatile composition
- [x] 32x32 block composition
- [x] Host-side PNG renderer
- [x] Procedural graphics test package
- [x] Emerald graphics probe (non-exporting)
- [x] 3DS-side decoder interface
- [ ] Actual user-supplied Emerald graphics adapter
- [ ] Animated player sprites
- [ ] Runtime map transitions
