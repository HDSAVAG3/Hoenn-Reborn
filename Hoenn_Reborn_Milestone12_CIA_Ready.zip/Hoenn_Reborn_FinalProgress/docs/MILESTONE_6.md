# Milestone 6 — Player Animation, Warps, Connections, Runtime Map Loading

Milestone 6 turns the single-map overworld prototype into a small runtime map
system. The project now has explicit player animation state, warp events,
cardinal map connections, and a runtime map registry.

## Player animation

`player_anim.c` provides a 4-direction, 4-frame walk-cycle state machine.
The state machine is renderer-neutral so a later C2D/GPU renderer can consume
the selected frame without changing movement logic. No Nintendo sprite assets
are distributed.

## Warps

`RuntimeWarp` maps a player coordinate to a destination map and destination
warp index. When the player reaches the source warp, the runtime loads the
destination map and places the player on the matching destination warp when it
is available.

## Map connections

`RuntimeConnection` models Emerald's cardinal `up/down/left/right`
connections and their signed offsets. The transition formulas follow the
connection-offset model used by the Emerald engine. North/south connections
adjust X by the connection offset; east/west connections adjust Y.

## Runtime map registry

`MapRuntime` owns the currently loaded map and can switch maps without the
movement or UI code knowing how maps are stored. `test_maps.c` provides two
project-owned test maps so transitions can be exercised without Nintendo data.

## Input

The 3DS runtime now uses held D-pad input for movement with a small repeat
interval. Panel buttons continue to use key-down events.

## Importer changes

The map-v2 importer now emits:

- zero-based `warp_id`
- `dest_map`
- `dest_warp_id`
- normalized connection direction/offset/destination

This is enough for a later generated map registry to resolve symbolic Emerald
map IDs into compact runtime IDs.

## Verification

Run:

```bash
python3 tools/milestone6_selftest.py
python3 tools/map_import_contract.py examples/littleroot_like.json
```

The second command validates the existing development fixture. A real
`pokeemerald` checkout can be imported with `emerald_layout_extract.py`.

## Next milestone

Milestone 7 should connect the renderer to the runtime map package and add a
real indexed sprite-sheet loader, map-specific collision/elevation data,
object-event rendering, and map-name/transition effects.

## Runtime code generation

`tools/map_runtime_codegen.py` converts a validated map-v2 JSON package into
C arrays and a `RuntimeMap` object. This keeps JSON parsing on the host side
and leaves the 3DS runtime with compact static data.

Example:

```bash
python3 tools/map_runtime_codegen.py examples/littleroot_like.json \
  --map-id 1 --ids examples/map_ids.json examples/littleroot_runtime.c
```

For a full Emerald build, generate a single ID manifest for the maps you want
to ship, then generate one C file per imported map and assemble the resulting
`RuntimeMap` objects into a registry.
