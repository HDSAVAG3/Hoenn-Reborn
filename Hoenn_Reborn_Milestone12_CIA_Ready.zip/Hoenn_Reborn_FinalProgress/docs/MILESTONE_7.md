# Milestone 7 — NPCs and Dialogue

Milestone 7 adds the first interactive overworld slice: map NPC definitions,
NPC collision, facing interaction, and a lightweight dialogue state machine.

## Runtime flow

1. Player moves normally unless an NPC occupies the destination tile.
2. Press A while facing an NPC to open that NPC's dialogue.
3. Dialogue reveals one character at a time.
4. Press A once to reveal the current line completely, then again to advance.
5. After the final line, dialogue closes and gameplay resumes.

The system is renderer-neutral at the data/state level and keeps dialogue data
as project-owned strings. It does not ship Pokémon game scripts or copyrighted
text/assets.

## Files

- `include/npc.h`, `src/npc.c` — NPC definitions, lookup, collision and facing.
- `include/dialogue.h`, `src/dialogue.c` — dialogue state and 3DS console renderer.
- `src/test_maps.c` — development NPC/dialogue fixtures.

## Validation

```bash
python3 tools/milestone7_selftest.py
```

## Next

Milestone 8 should replace the console dialogue renderer with a tiled text-box
renderer, add object-event templates, camera-aware NPC drawing, scripted event
hooks, and saveable event flags.
