# Milestone 3 — Overworld foundation

This milestone replaces the placeholder player movement with a real runtime
map abstraction and collision/camera path.

## Implemented

- Decoded-map data contract (`DecodedMap`)
- Metatile grid
- Collision grid
- Blocked movement prevention
- Four-direction player facing
- Camera following and map-edge clamping
- Touch dashboard retained independently from gameplay
- Built-in 20x15 test map so the runtime can be exercised without ROM data
- ROM manifest probe that records only hashes/header metadata

## Why the importer is separate

The project does not redistribute Nintendo ROM data. The runtime accepts
decoded map data, while an importer can run against a user's own local source
and emit project-owned/generated data.

## Next milestone

1. Connect an Emerald-specific extractor to the `DecodedMap` contract.
2. Decode layouts/metatiles from the user's local source.
3. Add 8x8 tile graphics and 16x16 metatile composition.
4. Replace the text map view with a native framebuffer/Citro3D renderer.
5. Add player sprite sheets and directional animation.
6. Add map connections and warps.
7. Add encounter zones and battle transition.
8. Add native save storage.

The open-source `pret/pokeemerald` project is a useful technical reference
for the map/layout model; this project does not copy its copyrighted game
assets.
