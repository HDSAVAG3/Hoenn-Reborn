# Milestone 5 — Graphical Overworld Pipeline

Milestone 5 replaces the text-only block preview with a project-owned graphical
pipeline. The pipeline mirrors the relevant Emerald hierarchy without shipping
Nintendo graphics:

**GBA 4bpp tile -> 8x8 tile -> 16x16 metatile -> 32x32 block -> map**

The host renderer can decode standard GBA 4bpp tile data, RGB555 palettes,
compose metatiles and blocks, and export a PNG preview. The 3DS runtime gets a
matching RGBA renderer interface so the same decoded map can later be uploaded
to a texture/framebuffer.

## Commands

Create the procedural development graphics and render them:

```bash
python3 tools/make_test_gfx.py examples/gfx_test
python3 tools/render_map.py examples/gfx_test/map.json examples/gfx_test/out.png
```

Inspect a user's local Emerald graphics tree without copying assets into the
project:

```bash
python3 tools/emerald_graphics_probe.py /path/to/pokeemerald LittlerootTown
```

The probe reports candidate tileset graphics/palette/metatile files. It does
not export copyrighted assets.

## Runtime model

A map block is treated as four 16x16 metatiles arranged 2x2. Each metatile is
four 8x8 tiles. The exact source-side metatile record layout remains an adapter
boundary because Emerald variants/tools can expose graphics in different forms.

The renderer accepts a normalized, project-owned representation:

- `tiles_4bpp.bin`: packed 4bpp GBA tiles
- `palette.json`: 16 RGB555 colors per palette
- `metatiles.json`: 4 tile references per 16x16 metatile
- `blocks.json`: 4 metatile references per 32x32 block
- `map.json`: block IDs in map order

## Next milestone

Milestone 6 will connect the graphical renderer to player sprite sheets,
animated walking frames, map warps/connections, and actual map-to-map loading.
