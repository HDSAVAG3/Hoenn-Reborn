# Milestone 4 — Emerald map import pipeline

This milestone makes the importer boundary concrete. A local `pokeemerald`
decompilation tree can now provide map metadata and layout block IDs without
copying the original game's graphics or ROM bytes into this project.

## Implemented

- `hoenn-reborn-map-v2` runtime/import format.
- Emerald layout lookup through `data/layouts/layouts.json`.
- Map lookup through `data/maps/<MapName>/map.json`.
- Little-endian layout blockdata extraction.
- Primary/secondary tileset IDs preserved as metadata.
- Map connections and warp metadata preserved for the next overworld step.
- Border dimensions preserved.
- Import validation updated for the v2 schema.
- Runtime test map expanded to 40x30 to exercise camera scrolling and collision.

## Usage

```text
python3 tools/emerald_layout_extract.py /path/to/pokeemerald LittlerootTown build/littleroot.json
python3 tools/map_import_contract.py build/littleroot.json
```

The extractor expects the local source tree to contain the standard Emerald
`data/maps` and `data/layouts` structure. The upstream project documents that
maps are represented by map JSON plus layout data, and its build system uses
those files to generate map headers and layout tables.

## Important limitation

A layout's block IDs are not yet the final on-screen graphics. Milestone 5
will add a project-owned tile renderer that consumes user-supplied/generated
8x8 tile graphics and tileset metadata. Collision should likewise be replaced
with decoded behavior data before treating a map as production-ready.

No Nintendo graphics, audio, scripts, or ROM bytes are included in this
repository.
