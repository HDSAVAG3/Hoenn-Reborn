# Milestone 11 — Build Hardening & Release Preflight

Milestone 11 makes the project safer to carry between development machines and prepares the existing 3DS/CIA pipeline for a real devkitPro environment.

## Completed

- Switched the Makefile to explicitly use `$(DEVKITARM)/bin/arm-none-eabi-gcc` instead of relying on a host `CC`.
- Centralized the `3dsxtool` path in `$(DEVKITPRO)/tools/bin/3dsxtool`.
- Added a `make validate` target.
- Added `tools/milestone11_preflight.py` to verify required project files and run regression tests.
- Added `bannertool` to the toolchain preflight because CIA packaging requires it.
- Kept the Emerald ROM external; no ROM bytes are bundled in the project or release packaging.

## Validation performed in this workspace

The host-side regression suite passes:

- Milestone 6 self-test: PASS
- Milestone 7 self-test: PASS
- Milestone 8 structure test: PASS
- Warp smoke test: PASS
- Milestone 11 preflight: PASS

A real `.3dsx`/`.cia` was **not** produced here because this workspace does not contain the devkitPro/devkitARM toolchain and CIA packaging tools. The project is now set up to use those tools when built on a configured 3DS development machine.

## Next milestone

Milestone 12 should move the runtime from console diagnostics toward an actual 3DS graphical scene renderer: framebuffer-backed map presentation, player sprite rendering, camera clipping, and a clean separation between debug text and gameplay visuals.
