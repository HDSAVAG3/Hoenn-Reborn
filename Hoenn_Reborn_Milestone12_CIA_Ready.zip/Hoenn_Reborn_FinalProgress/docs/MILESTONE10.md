# Milestone 10 — CIA Build Pipeline

This milestone makes the project structurally ready for a Nintendo 3DS developer-toolchain build.

## Outputs
- `hoenn_reborn.3dsx` development build
- `hoenn_reborn.cia` installable package when devkitPro/makerom/bannertool are available

## Important
The supplied Pokémon Emerald ROM is **not embedded** in the application. It remains an external input for local extraction/import workflows.

## Build
1. Install a current devkitPro 3DS environment with devkitARM/libctru, 3dsxtool, makerom, and bannertool.
2. Run `make check-toolchain`.
3. Run `make` for the 3DSX.
4. Run `make cia` for the CIA package.

The build script intentionally stops with a clear error if the required external tools or package assets are unavailable.
