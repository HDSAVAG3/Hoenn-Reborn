# Emerald importer boundary

```text
Local pokeemerald source -> Emerald layout extractor -> map-v2 JSON -> 3DS runtime
```

The upstream `pokeemerald` architecture uses `data/maps/*/map.json` for map
metadata and `data/layouts/layouts.json` for layout dimensions, blockdata and
tileset references. The project build rules then generate map/layout tables.

Hoenn Reborn deliberately stops at a clean data boundary. The extractor
exports structure, not original game assets.

### v2 fields

- `width`, `height`: layout block grid dimensions
- `blocks`: one block ID per map cell
- `block_count`: highest referenced block ID + 1
- `collision`: one walkability byte per cell
- `border_width`, `border_height`
- `primary_tileset`, `secondary_tileset`
- `connections`
- `warps`

Collision currently defaults to walkable because layout block IDs alone are
not enough to reconstruct final gameplay behavior. A later behavior decoder
will replace that field.
