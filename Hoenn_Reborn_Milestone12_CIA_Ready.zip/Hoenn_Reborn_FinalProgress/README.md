# Pokémon Emerald: Hoenn Reborn — Milestone 7

Native Nintendo 3DS homebrew overworld project.

Milestone 6 adds the graphical overworld pipeline on top of the Emerald-compatible **local source layout importer**. The importer reads a user's local `pokeemerald` source
tree and emits a compact project-owned JSON map package containing layout
block IDs, dimensions, tileset identifiers, connections, and warp metadata.

## Build

Requires devkitPro, devkitARM, and libctru for the 3DS target. The runtime
source is intentionally separated from the host-side importer so the map
pipeline can be tested without a 3DS.

## Import a map

```bash
python3 tools/emerald_layout_extract.py /path/to/pokeemerald LittlerootTown build/littleroot.json
python3 tools/map_import_contract.py build/littleroot.json
```

## Current runtime

- Scrolling 40x30 test overworld
- Collision-aware player movement
- Four-direction facing
- Camera clamping
- Touch dashboard
- Import-ready block grid

## Milestone 5 graphical pipeline

The project now has a normalized graphics format, GBA 4bpp tile decoder, RGB555
palette conversion, 16x16 metatile composition, 32x32 block composition, and a
host-side PNG renderer. Run `python3 tools/make_test_gfx.py examples/gfx_test`
and then `python3 tools/render_map.py examples/gfx_test examples/gfx_test/out.png`
to exercise it with project-owned procedural graphics.

## Milestone 6 runtime

The project now has a renderer-neutral player animation state machine, runtime
warps, Emerald-style cardinal map connections with offsets, a map registry, and
held-input movement. Two project-owned test maps exercise map-to-map transitions.

See `docs/MILESTONE_6.md` for the details, code-generation flow, and validation commands.

## Milestone 7 NPC/dialogue pipeline

The runtime now includes NPC definitions, solid NPC collision, facing-based
interaction, multi-line dialogue, typewriter reveal, and a simple dialogue box.
The development maps include a Guide and Researcher so the interaction path can
be tested immediately.

Run `python3 tools/milestone7_selftest.py` for host-side validation.

## Next milestone

Milestone 8 will replace the console dialogue renderer with a tiled text-box
renderer, add object-event templates, camera-aware NPC drawing, scripted event
hooks, and saveable event flags.

## Data policy

This project does not distribute Nintendo ROM bytes or copyrighted Pokémon
assets. The importer is designed to operate on a user's own local source/data
and emit only the structural data required by the runtime.

## Milestone 8
Adds reusable event flags, scripted-event primitives, and a versioned local save-state foundation. SELECT writes `hoenn_reborn.sav` during runtime.

## Milestone 9 — Local Emerald ROM compatibility

Milestone 9 adds a metadata-only adapter for a locally supplied Emerald ROM. The adapter verifies the GBA header and creates `examples/emerald_rom_manifest.json`; the ROM itself remains external and is not packaged or copied into the project.

This gives the map/graphics import pipeline a verified input boundary for the local Emerald BPEE ROM while preserving the project's clean-room asset boundary.

## Milestone 11

Build hardening and release preflight are now included. Run `make validate` on a host with Python 3 to execute the dependency-free regression suite. A configured devkitPro/devkitARM environment is still required for actual `.3dsx` and `.cia` output.

## Milestone 12 — Graphical Scene

Milestone 12 replaces the top-screen console gameplay display with a framebuffer-backed RGB565 scene renderer. The top screen now draws the map, camera viewport, player animation, NPCs, gameplay HUD, and dialogue box. The bottom console is retained strictly for debug diagnostics.

See `docs/MILESTONE12.md` and run `python3 tools/milestone12_selftest.py`.

## Milestone 12 — Graphical Scene

Milestone 12 replaces the top-screen console gameplay display with a framebuffer-backed RGB565 scene renderer. The top screen now draws the map, camera viewport, player animation, NPCs, gameplay HUD, and dialogue box. The bottom console is retained strictly for debug diagnostics.

See `docs/MILESTONE12.md` and run `python3 tools/milestone12_selftest.py`.
