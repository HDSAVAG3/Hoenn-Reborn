Place user-created or properly licensed assets here. Do not distribute Nintendo ROM assets.
